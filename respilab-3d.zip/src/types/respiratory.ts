export type LabStage = 
  | 'welcome'
  | 'case'
  | 'anatomy'
  | 'breathing'
  | 'spirometry'
  | 'rate'
  | 'analysis'
  | 'engineering'
  | 'evaluation';

export interface StageInfo {
  id: LabStage;
  number: number;
  title: string;
  shortTitle: string;
  description: string;
  badge: string;
}

export interface AnatomicalStructure {
  id: string;
  name: string;
  latinName: string;
  category: 'airway' | 'lung_parenchyma' | 'musculature' | 'pleura' | 'microscopic';
  meshKey: string;
  description: string;
  function: string;
  histology: string;
  clinicalSignificance: string;
  keyJournalRef: string;
  position: [number, number, number];
  color: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  patient: {
    name: string;
    age: number;
    sex: string;
    occupation: string;
    chiefComplaint: string;
    historyOfPresentIllness: string;
    vitals: {
      heartRate: number;
      respiratoryRate: number;
      bloodPressure: string;
      spO2: number;
      temperature: number;
    };
  };
  clinicalHypotheses: string[];
  investigationMissions: {
    id: string;
    title: string;
    targetStage: LabStage;
    objective: string;
    isCompleted: boolean;
  }[];
  journalSource: string;
}

export interface SpirometryDataPoint {
  time: number; // seconds
  volume: number; // liters
  flow: number; // L/s
}

export interface SpirometryResult {
  fvc: number; // Liters
  fev1: number; // Liters
  fev1Ratio: number; // %
  pef: number; // L/s
  fef2575: number; // L/s
  pattern: 'Normal' | 'Obstructive (Mild)' | 'Obstructive (Severe)' | 'Restrictive';
  predictedFvc: number;
  predictedFev1: number;
}

export interface ExperimentTrial {
  id: string;
  timestamp: string;
  subjectCondition: string;
  ageGroup: string;
  activityLevel: string;
  altitude: number; // meters
  pathology: string;
  respiratoryRate: number; // breaths/min
  tidalVolume: number; // mL
  deadSpace: number; // mL
  minuteVentilation: number; // L/min
  alveolarVentilation: number; // L/min
  paO2Est: number; // mmHg
  paCO2Est: number; // mmHg
  phEst: number;
}

export interface EngineeringComponent {
  id: string;
  name: string;
  role: string;
  biologicalAnalog: string;
  iconName: string;
  isPlaced: boolean;
  targetSlotId: string;
  hint: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  scenario?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  journalCitation: string;
  category: 'Anatomy' | 'Mechanics' | 'Spirometry' | 'Gas Exchange' | 'Pathophysiology';
}
