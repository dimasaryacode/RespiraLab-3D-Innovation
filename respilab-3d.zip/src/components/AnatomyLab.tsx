import React, { useState } from 'react';
import { ANATOMICAL_STRUCTURES } from '../data/anatomyData';
import { AnatomicalStructure, LabStage } from '../types/respiratory';
import { LungCanvas } from './three/LungCanvas';
import { 
  Layers, 
  Info, 
  Microscope, 
  Stethoscope, 
  BookOpen, 
  ArrowRight, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

interface AnatomyLabProps {
  onCompleteMission?: () => void;
  onNextStage?: (stage: LabStage) => void;
}

export const AnatomyLab: React.FC<AnatomyLabProps> = ({ onCompleteMission, onNextStage }) => {
  const [selectedOrganId, setSelectedOrganId] = useState<string | null>('trachea');
  const [exploredOrgans, setExploredOrgans] = useState<Set<string>>(new Set(['trachea']));

  const activeOrgan: AnatomicalStructure = 
    ANATOMICAL_STRUCTURES.find(s => s.id === selectedOrganId) || ANATOMICAL_STRUCTURES[0];

  const handleOrganSelect = (id: string | null) => {
    setSelectedOrganId(id);
    if (id) {
      setExploredOrgans(prev => new Set(prev).add(id));
    }
  };

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 03 · 3D High-Res Morphometry</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Interactive 3D Pulmonary Anatomy Lab</h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400">
            Explored: <span className="font-mono text-cyan-400 font-bold">{exploredOrgans.size}</span> / {ANATOMICAL_STRUCTURES.length} structures
          </div>
          {onNextStage && (
            <button
              onClick={() => {
                if (onCompleteMission) onCompleteMission();
                onNextStage('breathing');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Breathing Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main 2-Zone Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column: 3D Interactive Canvas (7 cols on large desktop) */}
        <div className="lg:col-span-7 flex flex-col min-h-[580px]">
          <LungCanvas
            mode="anatomy"
            selectedOrganId={selectedOrganId}
            onOrganSelect={handleOrganSelect}
          />
        </div>

        {/* Right Column: Organ Directory & Deep Histological Inspector (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          {/* Quick Organ Directory Tabs */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2.5">
              Select Anatomical Landmark
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {ANATOMICAL_STRUCTURES.map((organ) => {
                const isSelected = selectedOrganId === organ.id;
                const isExplored = exploredOrgans.has(organ.id);

                return (
                  <button
                    key={organ.id}
                    onClick={() => handleOrganSelect(organ.id)}
                    className={`flex items-center justify-between p-2 rounded-xl text-left text-xs transition-all ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 font-semibold shadow-md'
                        : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800/80'
                    }`}
                  >
                    <span className="truncate pr-1">{organ.name.split(' (')[0]}</span>
                    {isExplored && (
                      <span className={`text-[10px] ${isSelected ? 'text-slate-950' : 'text-emerald-400'}`}>
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Inspector Card */}
          <div className="flex-1 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              {/* Organ Title & Latin Name */}
              <div className="border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-cyan-400 uppercase">{activeOrgan.category}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-xs italic text-slate-400 font-serif">{activeOrgan.latinName}</span>
                </div>
                <h3 className="font-display text-xl font-bold text-white mt-1">{activeOrgan.name}</h3>
              </div>

              {/* Anatomy & Morphometry Description */}
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeOrgan.description}
              </p>

              {/* Functional Physiology */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-400">
                  <Info className="w-3.5 h-3.5" />
                  <span>Physiological Function</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {activeOrgan.function}
                </p>
              </div>

              {/* Histology & Microscopic Architecture */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-teal-400">
                  <Microscope className="w-3.5 h-3.5" />
                  <span>Histological Ultrastructure</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {activeOrgan.histology}
                </p>
              </div>

              {/* Clinical Significance */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-400">
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>Clinical Correlation</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {activeOrgan.clinicalSignificance}
                </p>
              </div>
            </div>

            {/* Scientific Citation Footer */}
            <div className="pt-3 border-t border-slate-800 flex items-center gap-2 text-[11px] text-slate-400">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate">{activeOrgan.keyJournalRef}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
