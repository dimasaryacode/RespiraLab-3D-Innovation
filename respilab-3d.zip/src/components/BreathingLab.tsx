import React, { useState, useEffect } from 'react';
import { LungCanvas } from './three/LungCanvas';
import { LabStage } from '../types/respiratory';
import { 
  Play, 
  Pause, 
  Wind, 
  Gauge, 
  Activity, 
  ArrowRight, 
  Sliders, 
  RefreshCw,
  BookOpen
} from 'lucide-react';

interface BreathingLabProps {
  onCompleteMission?: () => void;
  onNextStage?: (stage: LabStage) => void;
}

export const BreathingLab: React.FC<BreathingLabProps> = ({
  onCompleteMission,
  onNextStage
}) => {
  const [isAutoBreathing, setIsAutoBreathing] = useState(true);
  const [breathingEffort, setBreathingEffort] = useState<'quiet' | 'deep'>('quiet');
  const [respiratoryRate, setRespiratoryRate] = useState(14); // bpm
  const [manualPhase, setManualPhase] = useState(0.5); // 0 = end expiration, 1 = peak inspiration

  // Dynamic physical telemetry calculations based on Boyle's Law
  // Resting: Pip = -5 to -8 cmH2O; Palv = -1 to +1 cmH2O
  // Deep/Forced: Pip = -5 to -24 cmH2O; Palv = -3 to +3 cmH2O
  const amplitude = breathingEffort === 'deep' ? 19 : 3.0;
  const basePip = -5.0;
  const pip = basePip - (manualPhase * amplitude);
  
  // Alveolar pressure is negative during inflow (phase increasing) and positive during outflow
  // At phase 0 and 1, air stops moving so Palv = 0
  const palvAmplitude = breathingEffort === 'deep' ? 3.5 : 1.2;
  const palv = -Math.sin(manualPhase * Math.PI) * (isAutoBreathing ? palvAmplitude : (manualPhase < 0.5 ? -palvAmplitude : palvAmplitude));
  const ptp = palv - pip; // Transpulmonary pressure

  // Volume: Base FRC (~2400 mL) + phase * Tidal Volume (500 mL quiet, 2000 mL deep)
  const vtMax = breathingEffort === 'deep' ? 2200 : 500;
  const currentVolume = 2400 + Math.round(manualPhase * vtMax);

  // Auto phase timer when auto-breathing is active
  useEffect(() => {
    if (!isAutoBreathing) return;
    const interval = 50; // ms
    const cycleDuration = (60 / respiratoryRate) * 1000; // ms
    const step = (interval / cycleDuration) * 2;
    let dir = 1;

    const timer = setInterval(() => {
      setManualPhase(prev => {
        let next = prev + dir * step;
        if (next >= 1.0) {
          next = 1.0;
          dir = -1;
        } else if (next <= 0.0) {
          next = 0.0;
          dir = 1;
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [isAutoBreathing, respiratoryRate]);

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 04 · Pulmonary Biomechanics</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Mechanics of Ventilation &amp; Boyle’s Law</h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 p-1 bg-slate-900 border border-slate-800 rounded-xl">
            <button
              onClick={() => setIsAutoBreathing(true)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                isAutoBreathing ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Play className="w-3.5 h-3.5" />
              <span>Auto Cycle</span>
            </button>
            <button
              onClick={() => setIsAutoBreathing(false)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                !isAutoBreathing ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Pause className="w-3.5 h-3.5" />
              <span>Manual Slider</span>
            </button>
          </div>

          {onNextStage && (
            <button
              onClick={() => {
                if (onCompleteMission) onCompleteMission();
                onNextStage('spirometry');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Spirometry</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: 3D Stage + Biomechanics Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* 3D Real Animation Viewport (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col min-h-[580px]">
          <LungCanvas
            mode="breathing"
            breathingSpeed={respiratoryRate / 14}
            breathingEffort={breathingEffort}
            isAutoBreathing={isAutoBreathing}
            manualPhase={manualPhase}
          />
        </div>

        {/* Real-time Physiological Telemetry & Controls (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          {/* Interactive Parameters Deck */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" /> Ventilation Controls
              </span>
              <span className="text-xs font-mono text-cyan-400">
                {manualPhase < 0.5 ? 'INSPIRATION PHASE' : 'EXPIRATION PHASE'}
              </span>
            </div>

            {/* Effort Toggle */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-400 font-medium">Ventilatory Pattern</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setBreathingEffort('quiet')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all ${
                    breathingEffort === 'quiet'
                      ? 'bg-cyan-500/15 border-cyan-500/50 text-cyan-300'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Quiet Eupnea (Resting)
                </button>
                <button
                  onClick={() => setBreathingEffort('deep')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all ${
                    breathingEffort === 'deep'
                      ? 'bg-rose-500/15 border-rose-500/50 text-rose-300'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Forced Hyperpnea (Sprint)
                </button>
              </div>
            </div>

            {/* Rate Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 font-medium">Respiratory Rate (RR)</span>
                <span className="font-mono text-cyan-400 font-bold">{respiratoryRate} breaths/min</span>
              </div>
              <input
                type="range"
                min="8"
                max="45"
                value={respiratoryRate}
                onChange={e => setRespiratoryRate(parseInt(e.target.value))}
                className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Manual Phase Slider (when not auto) */}
            {!isAutoBreathing && (
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-300 font-medium">Respiratory Phase Excursion</span>
                  <span className="font-mono text-cyan-400 font-bold">{Math.round(manualPhase * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.02"
                  value={manualPhase}
                  onChange={e => setManualPhase(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>End-Expiration (FRC)</span>
                  <span>End-Inspiration</span>
                </div>
              </div>
            )}
          </div>

          {/* Real-time Boyle's Law & Pressure Telemetry Card */}
          <div className="flex-1 bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-cyan-400" /> Transmural Pressure Gauges
              </span>
              <span className="text-xs font-mono text-slate-400">P1·V1 = P2·V2</span>
            </div>

            {/* Pressure Readings 3-Column Strip */}
            <div className="grid grid-cols-3 gap-2.5">
              {/* Intrapleural Pressure */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Intrapleural (Pip)</span>
                <span className="text-lg font-mono font-bold text-sky-400 block mt-1">
                  {pip.toFixed(1)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">cm H₂O</span>
              </div>

              {/* Alveolar Pressure */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Alveolar (Palv)</span>
                <span className={`text-lg font-mono font-bold block mt-1 ${
                  palv < 0 ? 'text-cyan-400' : palv > 0 ? 'text-amber-400' : 'text-slate-300'
                }`}>
                  {palv > 0 ? `+${palv.toFixed(1)}` : palv.toFixed(1)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">cm H₂O</span>
              </div>

              {/* Transpulmonary Pressure */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Transpulm (Ptp)</span>
                <span className="text-lg font-mono font-bold text-emerald-400 block mt-1">
                  +{Math.abs(ptp).toFixed(1)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">cm H₂O</span>
              </div>
            </div>

            {/* Instantaneous Lung Volume Gauge */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-semibold">Total Pulmonic Volume</span>
                <span className="font-mono text-cyan-400 font-bold">{currentVolume} mL</span>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-cyan-500 to-sky-400 h-full transition-all duration-75"
                  style={{ width: `${Math.min(100, (currentVolume / 5800) * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>Residual (1200)</span>
                <span>FRC (2400)</span>
                <span>TLC (5800 mL)</span>
              </div>
            </div>

            {/* Biomechanical Explanation Callout */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs text-slate-300 space-y-1">
              <span className="font-semibold text-slate-200 block">Guyton Biomechanics Note:</span>
              <p className="leading-relaxed text-[11px] text-slate-400">
                During inspiration, diaphragmatic descent and rib elevation increase thoracic cavity volume. By Boyle's law ($P \propto 1/V$), intrapleural pressure drops from -5 to -8 cm H₂O. This transmural suction stretches the elastic lungs, dropping alveolar pressure below zero (-1 cm H₂O), drawing ~500 mL of ambient air into the airways until equilibrium is reached.
              </p>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center gap-2 text-[11px] text-slate-400">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>West's Respiratory Physiology, Chapter 7: Mechanics of Breathing</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
