import React, { useEffect, useRef, useState } from 'react';
import { LungSceneManager } from './LungScene';
import { RotateCw, Eye, Layers, Compass, Wind, ZoomIn, ZoomOut } from 'lucide-react';

interface LungCanvasProps {
  onOrganSelect?: (organId: string | null) => void;
  selectedOrganId?: string | null;
  mode?: 'anatomy' | 'breathing';
  breathingSpeed?: number;
  breathingEffort?: 'quiet' | 'deep';
  isAutoBreathing?: boolean;
  manualPhase?: number; // 0 to 1
  onPhaseChange?: (phase: number) => void;
}

export const LungCanvas: React.FC<LungCanvasProps> = ({
  onOrganSelect,
  selectedOrganId,
  mode = 'anatomy',
  breathingSpeed = 1.0,
  breathingEffort = 'quiet',
  isAutoBreathing = true,
  manualPhase = 0,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneManagerRef = useRef<LungSceneManager | null>(null);

  // HUD state
  const [exploded, setExploded] = useState(0);
  const [opacity, setOpacity] = useState(0.85);
  const [activePreset, setActivePreset] = useState<'anterior' | 'posterior' | 'lateral' | 'diaphragm' | 'alveolar'>('anterior');
  const [isControlsOpen, setIsControlsOpen] = useState(true);

  // Initialize Three.js scene once
  useEffect(() => {
    if (!mountRef.current) return;

    const manager = new LungSceneManager(mountRef.current, {
      onOrganSelect,
      isBreathingLab: mode === 'breathing'
    });
    sceneManagerRef.current = manager;

    const handleResize = () => {
      manager.handleResize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      manager.dispose();
      sceneManagerRef.current = null;
    };
  }, []);

  // Sync selected organ
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setSelectedOrgan(selectedOrganId ?? null);
    }
  }, [selectedOrganId]);

  // Sync mode and breathing controls
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.isAutoBreathing = isAutoBreathing;
      sceneManagerRef.current.breathingSpeed = breathingSpeed * (breathingEffort === 'deep' ? 1.4 : 1.0);
      if (!isAutoBreathing && manualPhase !== undefined) {
        sceneManagerRef.current.breathingPhase = manualPhase;
      }
    }
  }, [isAutoBreathing, breathingSpeed, breathingEffort, manualPhase]);

  // Sync exploded view slider
  const handleExplodedChange = (val: number) => {
    setExploded(val);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setExplodedDistance(val);
    }
  };

  // Sync opacity slider
  const handleOpacityChange = (val: number) => {
    setOpacity(val);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setLungOpacity(val);
    }
  };

  // Camera preset handler
  const handlePresetSelect = (preset: 'anterior' | 'posterior' | 'lateral' | 'diaphragm' | 'alveolar') => {
    setActivePreset(preset);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setCameraPreset(preset);
    }
  };

  return (
    <div className="relative w-full h-full min-h-[500px] overflow-hidden bg-slate-950 rounded-2xl border border-slate-800/80 shadow-2xl flex flex-col justify-between">
      {/* 3D Scene Viewport Mount Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Spec / Viewport Badge */}
      <div className="relative z-10 flex items-center justify-between p-4 pointer-events-none">
        <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-700/80 px-3 py-1.5 rounded-lg pointer-events-auto shadow-md">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-semibold tracking-wide text-slate-200">
            {mode === 'anatomy' ? '3D RESPIRATORY ANATOMY ENGINE' : 'VENTILATION BIOMECHANICS SIMULATOR'}
          </span>
          <span className="text-slate-500 text-xs">·</span>
          <span className="text-xs font-mono text-cyan-400">WebGL PBR 60 FPS</span>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-700/80 px-3 py-1.5 rounded-lg pointer-events-auto text-xs text-slate-300">
          <RotateCw className="w-3.5 h-3.5 text-slate-400" />
          <span>Click & Drag to Orbit · Scroll to Zoom</span>
        </div>
      </div>

      {/* Collapsible Unified Bottom Control Dock (Zero Viewport Occlusion per Three.js skill) */}
      <div className="relative z-10 mb-4 mx-auto max-w-3xl w-full px-4 pointer-events-auto">
        <div className="flex justify-center mb-1">
          <button
            onClick={() => setIsControlsOpen(!isControlsOpen)}
            className="px-3 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900/90 border border-slate-700/70 rounded-t-lg transition-colors flex items-center gap-1.5 shadow-md"
          >
            <span>{isControlsOpen ? '▾ Hide Viewport Dock' : '▴ Expand Viewport Dock'}</span>
          </button>
        </div>

        {isControlsOpen && (
          <div className="bg-slate-900/95 border border-slate-700/80 rounded-xl p-3 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-3 items-center">
            {/* Column 1: Camera Presets */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-slate-400 flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-cyan-400" /> Camera Angle
              </span>
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                {(['anterior', 'posterior', 'lateral', 'diaphragm', 'alveolar'] as const).map(p => (
                  <button
                    key={p}
                    onClick={() => handlePresetSelect(p)}
                    className={`px-2 py-1 text-[11px] font-medium rounded capitalize transition-colors flex-1 text-center ${
                      activePreset === p
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {p === 'diaphragm' ? 'Base' : p === 'alveolar' ? 'Micro' : p}
                  </button>
                ))}
              </div>
            </div>

            {/* Column 2: Exploded View Slider */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" /> Exploded Lobe View
                </span>
                <span className="font-mono text-cyan-400">{Math.round(exploded * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={exploded}
                onChange={e => handleExplodedChange(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Column 3: Parenchyma Transparency */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-cyan-400" /> Lung Transparency
                </span>
                <span className="font-mono text-cyan-400">{Math.round((1 - opacity) * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.15"
                max="1.0"
                step="0.05"
                value={opacity}
                onChange={e => handleOpacityChange(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
