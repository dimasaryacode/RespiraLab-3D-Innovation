export interface Citation {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  doiOrUrl: string;
  summary: string;
  keyTopics: string[];
}

export const LITERATURE_CITATIONS: Citation[] = [
  {
    id: 'ats_spirometry_2019',
    title: 'Standardization of Spirometry 2019 Update. An Official American Thoracic Society and European Respiratory Society Technical Statement',
    authors: 'Graham, B. L., Steenbruggen, I., Miller, M. R., Barjaktarevic, I. Z., Cooper, B. G., et al.',
    journal: 'American Journal of Respiratory and Critical Care Medicine, 200(8), e70–e88',
    year: 2019,
    doiOrUrl: '10.1164/rccm.201908-1590ST',
    summary: 'Definitive international clinical criteria for spirometric acceptability, repeatability, FEV1 measurement from back-extrapolated time zero (VBE), and LLN criteria.',
    keyTopics: ['Spirometry', 'FVC', 'FEV1', 'Flow-Volume Loop', 'Acceptability Criteria']
  },
  {
    id: 'west_respiratory_2021',
    title: "West's Respiratory Physiology: The Essentials (11th Edition)",
    authors: 'West, J. B., & Luks, A. M.',
    journal: 'Wolters Kluwer / Lippincott Williams & Wilkins, Philadelphia',
    year: 2021,
    doiOrUrl: 'ISBN: 978-1975139186',
    summary: 'Foundational textbook on pulmonary ventilation, transmural pressures, ventilation-perfusion relationships, gas transport, and mechanics of breathing.',
    keyTopics: ['Ventilation Mechanics', 'Intrapleural Pressure', 'Compliance', 'V/Q Ratio']
  },
  {
    id: 'guyton_physiology_2021',
    title: 'Guyton and Hall Textbook of Medical Physiology (14th Edition)',
    authors: 'Hall, J. E., & Hall, M. E.',
    journal: 'Elsevier Health Sciences',
    year: 2021,
    doiOrUrl: 'ISBN: 978-0323597128',
    summary: 'Comprehensive reference for respiratory neuroregulation, chemoreceptor feedback loops (central vs peripheral), surfactant surface tension, and high-altitude adaptation.',
    keyTopics: ['Neural Control', 'Boyle’s Law', 'Surfactant', 'Chemoreceptors', 'Dead Space']
  },
  {
    id: 'parsons_eib_2013',
    title: 'An Official American Thoracic Society Clinical Practice Guideline: Exercise-Induced Bronchoconstriction',
    authors: 'Parsons, J. P., Hallstrand, T. S., Mastronarde, J. G., Kaminsky, D. A., et al.',
    journal: 'American Journal of Respiratory and Critical Care Medicine, 187(9), 1016–1027',
    year: 2013,
    doiOrUrl: '10.1164/rccm.201303-0437ST',
    summary: 'Pathophysiology of airway dehydration, hyperosmolar mast cell degranulation, and bronchial smooth muscle constriction occurring post-exercise.',
    keyTopics: ['EIB', 'Exercise Physiology', 'Bronchoconstriction', 'Athlete Health']
  },
  {
    id: 'luks_altitude_2019',
    title: 'Wilderness Medical Society Clinical Practice Guidelines for the Prevention and Treatment of Acute Altitude Illness: 2019 Update',
    authors: 'Luks, A. M., Auerbach, P. S., Freer, L., et al.',
    journal: 'Wilderness & Environmental Medicine, 30(4S), S3–S18',
    year: 2019,
    doiOrUrl: '10.1016/j.wem.2019.04.006',
    summary: 'Mechanism of hypobaric hypoxia, carotid body glomus cell activation, hyperventilation-induced respiratory alkalosis, and renal bicarbonate wasting.',
    keyTopics: ['Altitude Physiology', 'Hypobaric Hypoxia', 'Hyperventilation', 'Carotid Bodies']
  },
  {
    id: 'raghu_ipf_2018',
    title: 'Diagnosis of Idiopathic Pulmonary Fibrosis: An Official ATS/ERS/JRS/ALAT Clinical Practice Guideline',
    authors: 'Raghu, G., Remy-Jardin, M., Myers, J. L., et al.',
    journal: 'American Journal of Respiratory and Critical Care Medicine, 198(5), e44–e68',
    year: 2018,
    doiOrUrl: '10.1164/rccm.201807-1255ST',
    summary: 'Fibrotic lung remodeling, reduced dynamic compliance, elevated transpulmonary pressure requirements, and characteristic restrictive spirometry patterns.',
    keyTopics: ['Restrictive Disease', 'Lung Compliance', 'Alveolar Fibrosis', 'FEV1/FVC Ratio']
  }
];
