import React, { useState } from 'react';
import { LabStage, ExperimentTrial } from './types/respiratory';
import { Navbar } from './components/Navbar';
import { StationSelector } from './components/StationSelector';
import { WelcomeLab } from './components/WelcomeLab';
import { InvestigationCase } from './components/InvestigationCase';
import { AnatomyLab } from './components/AnatomyLab';
import { BreathingLab } from './components/BreathingLab';
import { SpirometryLab } from './components/SpirometryLab';
import { RespiratoryRateLab } from './components/RespiratoryRateLab';
import { DataAnalysis } from './components/DataAnalysis';
import { EngineeringChallenge } from './components/EngineeringChallenge';
import { EvaluationLab } from './components/EvaluationLab';
import { BookOpen, ShieldCheck } from 'lucide-react';

export default function App() {
  const [currentStage, setCurrentStage] = useState<LabStage>('welcome');
  const [completedStages, setCompletedStages] = useState<LabStage[]>(['welcome']);

  // Initial peer-reviewed baseline trials for Data Analysis
  const [trials, setTrials] = useState<ExperimentTrial[]>([
    {
      id: 'trial_baseline_rest',
      timestamp: '09:00:15',
      subjectCondition: 'ADULT · REST',
      ageGroup: 'adult',
      activityLevel: 'rest',
      altitude: 0,
      pathology: 'none',
      respiratoryRate: 14,
      tidalVolume: 500,
      deadSpace: 150,
      minuteVentilation: 7.00,
      alveolarVentilation: 4.90,
      paO2Est: 98,
      paCO2Est: 40,
      phEst: 7.40
    },
    {
      id: 'trial_marcus_sprint',
      timestamp: '09:14:40',
      subjectCondition: 'ADULT · SPRINT',
      ageGroup: 'adult',
      activityLevel: 'sprint',
      altitude: 0,
      pathology: 'none',
      respiratoryRate: 42,
      tidalVolume: 2100,
      deadSpace: 150,
      minuteVentilation: 88.20,
      alveolarVentilation: 81.90,
      paO2Est: 104,
      paCO2Est: 32,
      phEst: 7.46
    },
    {
      id: 'trial_denver_altitude',
      timestamp: '09:30:22',
      subjectCondition: 'ADULT · REST (1600m)',
      ageGroup: 'adult',
      activityLevel: 'rest',
      altitude: 1600,
      pathology: 'none',
      respiratoryRate: 16,
      tidalVolume: 520,
      deadSpace: 150,
      minuteVentilation: 8.32,
      alveolarVentilation: 5.92,
      paO2Est: 78,
      paCO2Est: 37,
      phEst: 7.42
    }
  ]);

  const markStageCompleted = (stage: LabStage) => {
    setCompletedStages(prev => Array.from(new Set([...prev, stage])));
  };

  const handleSelectStage = (stage: LabStage) => {
    setCurrentStage(stage);
    markStageCompleted(stage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogTrial = (newTrial: ExperimentTrial) => {
    setTrials(prev => [newTrial, ...prev]);
    markStageCompleted('rate');
    markStageCompleted('analysis');
  };

  const handleClearTrials = () => {
    setTrials([]);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* 1. Header (Navbar adhering to 3-zone contract) */}
      <Navbar
        currentStage={currentStage}
        onSelectStage={handleSelectStage}
        completedStages={completedStages}
      />

      {/* 2. Sub-Header: Nine Sequential Laboratory Stations Progress Bar */}
      <StationSelector
        currentStage={currentStage}
        onSelectStage={handleSelectStage}
        completedStages={completedStages}
      />

      {/* 3. Main Workspace Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-4">
        {currentStage === 'welcome' && (
          <WelcomeLab
            onStart={() => handleSelectStage('case')}
            onSelectStage={handleSelectStage}
          />
        )}

        {currentStage === 'case' && (
          <InvestigationCase
            onSelectStage={handleSelectStage}
            completedStages={completedStages}
          />
        )}

        {currentStage === 'anatomy' && (
          <AnatomyLab
            onCompleteMission={() => markStageCompleted('anatomy')}
            onNextStage={handleSelectStage}
          />
        )}

        {currentStage === 'breathing' && (
          <BreathingLab
            onCompleteMission={() => markStageCompleted('breathing')}
            onNextStage={handleSelectStage}
          />
        )}

        {currentStage === 'spirometry' && (
          <SpirometryLab
            onCompleteMission={() => markStageCompleted('spirometry')}
            onNextStage={handleSelectStage}
          />
        )}

        {currentStage === 'rate' && (
          <RespiratoryRateLab
            onLogTrial={handleLogTrial}
            onNextStage={handleSelectStage}
            trialsCount={trials.length}
          />
        )}

        {currentStage === 'analysis' && (
          <DataAnalysis
            trials={trials}
            onClearTrials={handleClearTrials}
            onNextStage={handleSelectStage}
          />
        )}

        {currentStage === 'engineering' && (
          <EngineeringChallenge
            onCompleteMission={() => markStageCompleted('engineering')}
            onNextStage={handleSelectStage}
          />
        )}

        {currentStage === 'evaluation' && (
          <EvaluationLab
            onCompleteEvaluation={() => markStageCompleted('evaluation')}
          />
        )}
      </main>

      {/* 4. Quiet Footer adhering to anti-slop guidelines */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 px-6 py-8 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-slate-300">PulmoLab 3D</span>
            <span aria-hidden="true">·</span>
            <span>Respiratory Physiology &amp; Biomechanics Research Suite</span>
          </div>

          <div className="flex items-center gap-6 text-slate-400">
            <span>ATS/ERS Spirometry 2019</span>
            <span aria-hidden="true">·</span>
            <span>Guyton &amp; Hall Medical Physiology</span>
            <span aria-hidden="true">·</span>
            <span>West's Respiratory Physiology</span>
          </div>

          <p className="text-[11px] text-slate-600">
            For academic and clinical training simulation only.
          </p>
        </div>
      </footer>
    </div>
  );
}
