import { CaseStudy } from '../types/respiratory';

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'case_marcus_eib',
    title: 'Case #RP-402: Exertional Dyspnea in an Elite Collegiate Runner',
    patient: {
      name: 'Marcus Vance',
      age: 24,
      sex: 'Male',
      occupation: 'Collegiate Track & Cross-Country Athlete',
      chiefComplaint: '"Severe chest tightness and wheezing occurring 8–10 minutes after initiating high-intensity track interval training."',
      historyOfPresentIllness: 'A 24-year-old collegiate 5,000m runner presents with recurring episodes of post-exertional dyspnea, dry coughing, and retrosternal tightness over the past 4 months, worsening when running in cold morning air (4°C). Denies childhood asthma, smoking, or family history of cardiopulmonary disorders. Resting baseline vitals are pristine, but high-ventilation efforts provoke acute drop in peak expiratory flow.',
      vitals: {
        heartRate: 58,
        respiratoryRate: 14,
        bloodPressure: '118/74 mmHg',
        spO2: 99,
        temperature: 36.8
      }
    },
    clinicalHypotheses: [
      'Exercise-Induced Bronchoconstriction (EIB) with transient airway smooth muscle spasm triggered by mucosal dehydration and hyperosmolarity',
      'Vocal Cord Dysfunction / Exercise-Induced Laryngeal Obstruction (EILO) simulating asthma during peak inspiratory flow',
      'Diaphragmatic fatigue or transient acute thoracic restriction due to ribcage compliance limitations',
      'Early Interstitial Lung Disease (ILD) with impaired gas diffusion capacity'
    ],
    investigationMissions: [
      {
        id: 'mission_1',
        title: '3D Airway & Lobar Architecture Inspection',
        targetStage: 'anatomy',
        objective: 'Inspect the tracheobronchial branching tree to locate mucosal smooth muscle and carinal bifurcation.',
        isCompleted: false
      },
      {
        id: 'mission_2',
        title: 'Pleural & Alveolar Pressure Verification',
        targetStage: 'breathing',
        objective: 'Test whether negative intrapleural pressure excursion during forced hyperpnea drops below -20 cm H2O.',
        isCompleted: false
      },
      {
        id: 'mission_3',
        title: 'Standardized ATS/ERS Spirometry Challenge',
        targetStage: 'spirometry',
        objective: 'Perform a forced vital capacity maneuver to calculate baseline and post-challenge FEV1 and FEV1/FVC ratio.',
        isCompleted: false
      },
      {
        id: 'mission_4',
        title: 'Comparative Rate & High-Load Dynamics',
        targetStage: 'rate',
        objective: 'Simulate sprint-level ventilation rates (40+ bpm) and examine impact on tidal volume and dead space ventilation.',
        isCompleted: false
      },
      {
        id: 'mission_5',
        title: 'Alveolar Gas Equation & Ventilation Ratio',
        targetStage: 'analysis',
        objective: 'Compute Minute Ventilation (VE) vs Alveolar Ventilation (VA) to evaluate breathing efficiency.',
        isCompleted: false
      },
      {
        id: 'mission_6',
        title: 'Biomimetic Model Assembly & Manometer Test',
        targetStage: 'engineering',
        objective: 'Construct the classic bell jar model to verify physical transpulmonary inflation dynamics.',
        isCompleted: false
      }
    ],
    journalSource: 'Parsons, J. P., et al. (2013). "An official American Thoracic Society clinical practice guideline: exercise-induced bronchoconstriction." American Journal of Respiratory and Critical Care Medicine, 187(9), 1016-1027.'
  },
  {
    id: 'case_eleanor_ipf',
    title: 'Case #RP-108: Progressive Exertional Breathlessness in a 62-Year-Old',
    patient: {
      name: 'Eleanor Vance',
      age: 62,
      sex: 'Female',
      occupation: 'Retired Landscape Architect',
      chiefComplaint: '"Shortness of breath on mild exertion, dry persistent cough for 6 months, and inability to climb one flight of stairs."',
      historyOfPresentIllness: 'A 62-year-old female presents with insidious onset of progressive dyspnea on exertion. Physical exam reveals end-inspiratory "Velcro-like" crackles at bilateral lung bases and digital clubbing. Chest radiograph shows bilateral reticular opacities with subpleural and basilar predominance.',
      vitals: {
        heartRate: 84,
        respiratoryRate: 22,
        bloodPressure: '134/82 mmHg',
        spO2: 93,
        temperature: 37.0
      }
    },
    clinicalHypotheses: [
      'Idiopathic Pulmonary Fibrosis (IPF) / Restrictive Lung Disease with decreased lung compliance',
      'Chronic Obstructive Pulmonary Disease (COPD) with peripheral airway obstruction',
      'Congestive Heart Failure with secondary pulmonary venous hypertension',
      'Extrinsic allergic alveolitis / Hypersensitivity pneumonitis'
    ],
    investigationMissions: [
      {
        id: 'mission_1',
        title: 'Alveolar-Capillary Barrier Thickening Study',
        targetStage: 'anatomy',
        objective: 'Examine alveolar septum structure to understand diffusion limitation.',
        isCompleted: false
      },
      {
        id: 'mission_2',
        title: 'Lung Compliance & Recoil Curve in Breathing Lab',
        targetStage: 'breathing',
        objective: 'Observe increased elastic recoil requiring higher transmural distending pressure.',
        isCompleted: false
      },
      {
        id: 'mission_3',
        title: 'Restrictive Pattern Spirometry Assessment',
        targetStage: 'spirometry',
        objective: 'Verify reduced FVC with preserved or elevated FEV1/FVC ratio (>80%).',
        isCompleted: false
      },
      {
        id: 'mission_4',
        title: 'Tachypnea & Physiological Compensation',
        targetStage: 'rate',
        objective: 'Demonstrate rapid shallow breathing pattern minimizing elastic work of breathing.',
        isCompleted: false
      },
      {
        id: 'mission_5',
        title: 'A-a Oxygen Gradient & Diffusion Calculation',
        targetStage: 'analysis',
        objective: 'Calculate Alveolar-arterial O2 difference and physiological dead space ratio.',
        isCompleted: false
      },
      {
        id: 'mission_6',
        title: 'Stiff Balloon Model Biomechanical Stress',
        targetStage: 'engineering',
        objective: 'Test how reduced membrane elasticity alters volume displacement in the mechanical thorax.',
        isCompleted: false
      }
    ],
    journalSource: 'Raghu, G., et al. (2018). "Diagnosis of idiopathic pulmonary fibrosis: an official ATS/ERS/JRS/ALAT clinical practice guideline." American Journal of Respiratory and Critical Care Medicine, 198(5), e44-e68.'
  }
];
