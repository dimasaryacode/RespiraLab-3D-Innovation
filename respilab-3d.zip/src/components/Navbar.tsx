import React from 'react';
import { LabStage } from '../types/respiratory';
import { Activity, BookOpen } from 'lucide-react';

interface NavbarProps {
  currentStage: LabStage;
  onSelectStage: (stage: LabStage) => void;
  completedStages: LabStage[];
}

export const Navbar: React.FC<NavbarProps> = ({
  currentStage,
  onSelectStage,
  completedStages
}) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 border-b border-slate-800/80 px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark in display face */}
        <div 
          onClick={() => onSelectStage('welcome')}
          className="flex items-center gap-2.5 cursor-pointer shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Activity className="w-4 h-4" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap">
            PulmoLab<span className="text-cyan-400">3D</span>
          </span>
        </div>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => onSelectStage('welcome')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              currentStage === 'welcome' || currentStage === 'case' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Clinical Cases
          </button>
          <button
            onClick={() => onSelectStage('anatomy')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              currentStage === 'anatomy' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            3D Anatomy
          </button>
          <button
            onClick={() => onSelectStage('breathing')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              currentStage === 'breathing' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Ventilation Mechanics
          </button>
          <button
            onClick={() => onSelectStage('spirometry')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              currentStage === 'spirometry' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Spirometry Lab
          </button>
          <button
            onClick={() => onSelectStage('engineering')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              currentStage === 'engineering' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Thoracic Assembly
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onSelectStage('evaluation')}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap shadow-sm shadow-cyan-500/20"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Clinical Evaluation</span>
          </button>
        </div>
      </div>
    </header>
  );
};
