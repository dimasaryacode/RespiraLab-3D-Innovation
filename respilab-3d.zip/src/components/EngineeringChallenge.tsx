import React, { useState } from 'react';
import { EngineeringComponent, LabStage } from '../types/respiratory';
import { 
  Wrench, 
  CheckCircle2, 
  RotateCcw, 
  Play, 
  ArrowRight, 
  HelpCircle, 
  AlertTriangle,
  Layers,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface EngineeringChallengeProps {
  onCompleteMission?: () => void;
  onNextStage?: (stage: LabStage) => void;
}

export const EngineeringChallenge: React.FC<EngineeringChallengeProps> = ({
  onCompleteMission,
  onNextStage
}) => {
  // 6 Essential Components for the Bell Jar Thoracic Model
  const initialComponents: EngineeringComponent[] = [
    {
      id: 'jar',
      name: 'Clear Bell Jar',
      role: 'Rigid outer airtight container',
      biologicalAnalog: 'Rigid Thoracic Cage & Chest Wall',
      iconName: 'container',
      isPlaced: false,
      targetSlotId: 'slot_jar',
      hint: 'Forms the fixed outer structural boundary of the thorax.'
    },
    {
      id: 'stopper',
      name: 'Airtight Rubber Stopper',
      role: 'Hermetic apical seal',
      biologicalAnalog: 'Thoracic Inlet & Cervical Pleural Cupola',
      iconName: 'seal',
      isPlaced: false,
      targetSlotId: 'slot_stopper',
      hint: 'Seals the neck of the jar to prevent ambient air leakage.'
    },
    {
      id: 'ytube',
      name: 'Glass Y-Tube Conduit',
      role: 'Bifurcating airway conduit',
      biologicalAnalog: 'Trachea and Left/Right Primary Bronchi',
      iconName: 'tube',
      isPlaced: false,
      targetSlotId: 'slot_ytube',
      hint: 'Passes through the stopper to conduct atmospheric air.'
    },
    {
      id: 'balloons',
      name: 'Dual Latex Balloons',
      role: 'Compliant elastic air bladders',
      biologicalAnalog: 'Left and Right Lung Parenchyma',
      iconName: 'balloons',
      isPlaced: false,
      targetSlotId: 'slot_balloons',
      hint: 'Tied securely to the two lower limbs of the Y-tube.'
    },
    {
      id: 'diaphragm_sheet',
      name: 'Elastic Rubber Sheet',
      role: 'Flexible basal floor membrane',
      biologicalAnalog: 'Muscular Diaphragm Dome',
      iconName: 'sheet',
      isPlaced: false,
      targetSlotId: 'slot_diaphragm',
      hint: 'Stretched taut across the open bottom of the jar.'
    },
    {
      id: 'manometer',
      name: 'U-Tube Water Manometer',
      role: 'Differential fluid pressure sensor',
      biologicalAnalog: 'Intrapleural Pressure Gauge',
      iconName: 'manometer',
      isPlaced: false,
      targetSlotId: 'slot_manometer',
      hint: 'Measures subatmospheric pressure drops in the sealed space.'
    }
  ];

  const [components, setComponents] = useState<EngineeringComponent[]>(initialComponents);
  const [selectedCompId, setSelectedCompId] = useState<string | null>(null);

  // Operational Simulation State (once assembled)
  const isFullyAssembled = components.every(c => c.isPlaced);
  const [diaphragmDisplacement, setDiaphragmDisplacement] = useState<number>(0.5); // 0 (pushed in/expiration) to 1 (pulled out/inspiration)
  const [hasPneumothoraxLeak, setHasPneumothoraxLeak] = useState<boolean>(false);

  // Handle placing a component into its target slot
  const handlePlaceComponent = (compId: string) => {
    setComponents(prev => prev.map(c => c.id === compId ? { ...c, isPlaced: true } : c));
    setSelectedCompId(null);

    // Check if that was the last component
    const remaining = components.filter(c => c.id !== compId && !c.isPlaced);
    if (remaining.length === 0) {
      if (onCompleteMission) onCompleteMission();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    }
  };

  const handleResetAssembly = () => {
    setComponents(initialComponents);
    setSelectedCompId(null);
    setHasPneumothoraxLeak(false);
  };

  // Physical calculations for the interactive model:
  // When diaphragm is pulled down (displacement > 0.5):
  // Chamber volume increases -> Chamber pressure drops (Boyle's law)
  // Balloons inflate as atmospheric air rushes down Y-tube!
  // If pneumothorax leak is enabled: chamber pressure equals atmosphere, balloons stay collapsed!
  const effectiveDisplacement = hasPneumothoraxLeak ? 0 : diaphragmDisplacement;
  const balloonInflation = Math.max(0.15, effectiveDisplacement);
  const chamberPressure = hasPneumothoraxLeak ? 0 : (-12 * (diaphragmDisplacement - 0.2)); // cm H2O

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 08 · Biomimetic Lung Simulator Assembly</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Engineering Challenge: The Thoracic Bell Jar</h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleResetAssembly}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Rig</span>
          </button>

          {onNextStage && (
            <button
              onClick={() => {
                if (onCompleteMission) onCompleteMission();
                onNextStage('evaluation');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Clinical Evaluation</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Assembly Workspace: Component Parts vs Live Assembly Rig */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column (5 cols): Parts Workbench & Anatomical Analog Matcher */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-cyan-400" /> Component Workbench
              </span>
              <span className="text-xs font-mono text-cyan-400">
                {components.filter(c => c.isPlaced).length} / {components.length} Assembled
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Click a component below to mount it into the thoracic model. Match each physical hardware part to its biological pulmonary counterpart.
            </p>
          </div>

          {/* Component Inventory List */}
          <div className="space-y-2.5">
            {components.map((comp) => (
              <div
                key={comp.id}
                onClick={() => !comp.isPlaced && handlePlaceComponent(comp.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  comp.isPlaced
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60 cursor-default'
                    : 'bg-slate-900/90 hover:bg-slate-800/90 border-slate-700/80 hover:border-cyan-400 shadow-md'
                }`}
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white text-xs">{comp.name}</span>
                    {comp.isPlaced && (
                      <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Mounted
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-cyan-300 font-medium">
                    Biological Analog: <span className="text-slate-300">{comp.biologicalAnalog}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{comp.hint}</p>
                </div>

                {!comp.isPlaced && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePlaceComponent(comp.id);
                    }}
                    className="px-2.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg transition-colors shrink-0"
                  >
                    Mount
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (7 cols): Assembly Rig & Interactive Operating Simulator */}
        <div className="lg:col-span-7 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" /> Physical Thorax Simulation Rig
            </span>
            <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded-md ${
              isFullyAssembled
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
            }`}>
              {isFullyAssembled ? '✓ FULLY OPERATIONAL' : 'ASSEMBLY IN PROGRESS'}
            </span>
          </div>

          {/* The High-Fidelity SVG Physical Rig Display */}
          <div className="relative w-full h-[340px] bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 400 340" className="w-full h-full max-w-sm">
              {/* Bell Jar Container (if placed) */}
              {components.find(c => c.id === 'jar')?.isPlaced && (
                <path
                  d="M 140 60 Q 140 40 160 40 L 240 40 Q 260 40 260 60 L 260 250 L 140 250 Z"
                  fill="rgba(56, 189, 248, 0.05)"
                  stroke="#38bdf8"
                  strokeWidth="2.5"
                />
              )}

              {/* Rubber Stopper (if placed) */}
              {components.find(c => c.id === 'stopper')?.isPlaced && (
                <rect x="175" y="32" width="50" height="20" rx="3" fill="#475569" stroke="#94a3b8" strokeWidth="1.5" />
              )}

              {/* Glass Y-Tube (if placed) */}
              {components.find(c => c.id === 'ytube')?.isPlaced && (
                <g>
                  {/* Stem */}
                  <line x1="200" y1="15" x2="200" y2="90" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
                  <line x1="200" y1="15" x2="200" y2="90" stroke="#bae6fd" strokeWidth="2.5" />
                  {/* Right branch */}
                  <line x1="200" y1="90" x2="225" y2="125" stroke="#94a3b8" strokeWidth="5" strokeLinecap="round" />
                  <line x1="200" y1="90" x2="225" y2="125" stroke="#bae6fd" strokeWidth="2" />
                  {/* Left branch */}
                  <line x1="200" y1="90" x2="175" y2="125" stroke="#94a3b8" strokeWidth="5" strokeLinecap="round" />
                  <line x1="200" y1="90" x2="175" y2="125" stroke="#bae6fd" strokeWidth="2" />
                </g>
              )}

              {/* Balloons (if placed) - dynamically scaled by diaphragm displacement! */}
              {components.find(c => c.id === 'balloons')?.isPlaced && (
                <g>
                  {/* Left Balloon */}
                  <ellipse
                    cx="175"
                    cy={130 + balloonInflation * 25}
                    rx={12 + balloonInflation * 18}
                    ry={16 + balloonInflation * 28}
                    fill="#f43f5e"
                    opacity="0.85"
                    stroke="#fb7185"
                    strokeWidth="1.5"
                  />
                  {/* Right Balloon */}
                  <ellipse
                    cx="225"
                    cy={130 + balloonInflation * 25}
                    rx={12 + balloonInflation * 18}
                    ry={16 + balloonInflation * 28}
                    fill="#f43f5e"
                    opacity="0.85"
                    stroke="#fb7185"
                    strokeWidth="1.5"
                  />
                </g>
              )}

              {/* Rubber Diaphragm Sheet at bottom (if placed) */}
              {components.find(c => c.id === 'diaphragm_sheet')?.isPlaced && (
                <g>
                  <path
                    d={`M 140 250 Q 200 ${250 + (diaphragmDisplacement - 0.5) * 60} 260 250`}
                    fill="none"
                    stroke="#e11d48"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                  {/* Pull string / handle */}
                  <line
                    x1="200"
                    y1={250 + (diaphragmDisplacement - 0.5) * 30}
                    x2="200"
                    y2={290 + (diaphragmDisplacement - 0.5) * 40}
                    stroke="#cbd5e1"
                    strokeWidth="2"
                    strokeDasharray="2 2"
                  />
                  <circle
                    cx="200"
                    cy={295 + (diaphragmDisplacement - 0.5) * 40}
                    r="8"
                    fill="#38bdf8"
                  />
                </g>
              )}

              {/* U-Tube Manometer (if placed) */}
              {components.find(c => c.id === 'manometer')?.isPlaced && (
                <g transform="translate(300, 120)">
                  <path d="M 0 0 L 0 80 Q 15 95 30 80 L 30 20" fill="none" stroke="#64748b" strokeWidth="4" />
                  {/* Manometer Fluid differential */}
                  <path
                    d={`M 2 40 L 2 80 Q 15 93 28 80 L 28 ${50 - chamberPressure * 2}`}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="3"
                  />
                  <text x="36" y="50" fill="#94a3b8" fontSize="10" fontFamily="monospace">
                    {chamberPressure.toFixed(1)} cmH₂O
                  </text>
                </g>
              )}

              {/* Airflow arrows when pulling down */}
              {isFullyAssembled && diaphragmDisplacement > 0.6 && !hasPneumothoraxLeak && (
                <g transform="translate(200, 0)">
                  <line x1="0" y1="0" x2="0" y2="15" stroke="#38bdf8" strokeWidth="2" />
                  <polygon points="-3,15 3,15 0,20" fill="#38bdf8" />
                </g>
              )}
            </svg>

            {/* Pneumothorax alert banner overlay */}
            {hasPneumothoraxLeak && (
              <div className="absolute top-4 left-4 right-4 bg-rose-950/90 border border-rose-500/50 p-2.5 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>PNEUMOTHORAX LEAK ACTIVE: Atmospheric air entered chamber. Loss of negative pressure collapsed balloons!</span>
              </div>
            )}
          </div>

          {/* Interactive Operating Actuator (Enabled when fully assembled) */}
          {isFullyAssembled ? (
            <div className="space-y-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-cyan-400" /> Diaphragm Sheet Actuator
                </span>
                <span className="font-mono text-cyan-400">
                  Chamber Pressure: {chamberPressure.toFixed(1)} cm H₂O
                </span>
              </div>

              <div className="space-y-1.5">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.02"
                  value={diaphragmDisplacement}
                  onChange={e => setDiaphragmDisplacement(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>Push Up (Passive Expiration)</span>
                  <span>Resting (FRC)</span>
                  <span>Pull Down (Active Inspiration)</span>
                </div>
              </div>

              {/* Pneumothorax Breach Toggle */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-300">Pneumothorax Stress Test</span>
                  <p className="text-[11px] text-slate-400">Puncture seal to simulate open chest injury</p>
                </div>
                <button
                  onClick={() => setHasPneumothoraxLeak(!hasPneumothoraxLeak)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    hasPneumothoraxLeak
                      ? 'bg-rose-500 text-slate-950 border-rose-400'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  {hasPneumothoraxLeak ? 'Seal Puncture' : 'Puncture Chamber'}
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-400">
              Mount all 6 components from the left workbench to unlock the mechanical diaphragm actuator!
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
