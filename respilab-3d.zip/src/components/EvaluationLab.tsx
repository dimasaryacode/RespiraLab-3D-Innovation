import React, { useState } from 'react';
import { EVALUATION_QUESTIONS, CLINICAL_ABG_CASES } from '../data/evaluationData';
import { LITERATURE_CITATIONS } from '../data/literatureCitations';
import { 
  GraduationCap, 
  CheckCircle2, 
  XCircle, 
  BookOpen, 
  RotateCcw, 
  Award, 
  Activity, 
  HelpCircle,
  FileCheck2
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface EvaluationLabProps {
  onCompleteEvaluation?: () => void;
}

export const EvaluationLab: React.FC<EvaluationLabProps> = ({ onCompleteEvaluation }) => {
  // Quiz State
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submittedQuiz, setSubmittedQuiz] = useState<boolean>(false);

  // ABG State
  const [selectedAbgCase, setSelectedAbgCase] = useState<number>(0);
  const [abgUserAnswers, setAbgUserAnswers] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState<'mcq' | 'abg' | 'literature'>('mcq');

  const handleSelectAnswer = (qId: number, optIndex: number) => {
    if (submittedQuiz) return;
    setSelectedAnswers(prev => ({ ...prev, [qId]: optIndex }));
  };

  const calculateScore = () => {
    let score = 0;
    EVALUATION_QUESTIONS.forEach(q => {
      if (selectedAnswers[q.id] === q.correctAnswer) {
        score++;
      }
    });
    return score;
  };

  const handleSubmitQuiz = () => {
    setSubmittedQuiz(true);
    if (onCompleteEvaluation) onCompleteEvaluation();
    const score = calculateScore();
    if (score >= 4) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  const handleResetQuiz = () => {
    setSelectedAnswers({});
    setSubmittedQuiz(false);
  };

  const score = calculateScore();
  const total = EVALUATION_QUESTIONS.length;
  const percentage = Math.round((score / total) * 100);

  return (
    <div className="space-y-8 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 09 · Clinical Competency &amp; Board Mastery</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Evaluation &amp; Evidence-Based Feedback</h2>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setActiveTab('mcq')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'mcq'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Clinical Vignettes ({EVALUATION_QUESTIONS.length})
          </button>
          <button
            onClick={() => setActiveTab('abg')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'abg'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ABG Interpretation
          </button>
          <button
            onClick={() => setActiveTab('literature')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'literature'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Literature Citations
          </button>
        </div>
      </div>

      {/* Tab 1: Clinical MCQs with instant peer-reviewed feedback */}
      {activeTab === 'mcq' && (
        <div className="space-y-6">
          {/* Score Banner when submitted */}
          {submittedQuiz && (
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-slate-950 ${
                  percentage >= 75 ? 'bg-cyan-400' : 'bg-amber-400'
                }`}>
                  <Award className="w-8 h-8" />
                </div>
                <div>
                  <div className="text-xs uppercase font-mono tracking-wider text-slate-400">
                    Evaluation Performance
                  </div>
                  <h3 className="font-display text-2xl font-bold text-white">
                    {score} of {total} Questions Correct ({percentage}%)
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {percentage >= 75
                      ? 'Exemplary clinical reasoning! Mastery of pulmonary physiology demonstrated.'
                      : 'Good effort! Review the detailed rationales and journal citations below.'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleResetQuiz}
                className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake Evaluation</span>
              </button>
            </div>
          )}

          {/* Question Cards */}
          <div className="space-y-5">
            {EVALUATION_QUESTIONS.map((q, idx) => {
              const selectedOpt = selectedAnswers[q.id];
              const isAnswered = selectedOpt !== undefined;

              return (
                <div
                  key={q.id}
                  className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                      Question 0{idx + 1} · {q.category}
                    </span>
                    {submittedQuiz && (
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                        selectedOpt === q.correctAnswer
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}>
                        {selectedOpt === q.correctAnswer ? '✓ Correct' : '✕ Incorrect'}
                      </span>
                    )}
                  </div>

                  <h3 className="font-display text-base font-semibold text-white leading-snug">
                    {q.question}
                  </h3>

                  {q.scenario && (
                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 italic">
                      Clinical Scenario: {q.scenario}
                    </div>
                  )}

                  {/* Options */}
                  <div className="space-y-2 pt-1">
                    {q.options.map((opt, optIdx) => {
                      const isChosen = selectedOpt === optIdx;
                      const isCorrect = q.correctAnswer === optIdx;

                      let btnStyle = 'bg-slate-950/60 hover:bg-slate-800 border-slate-800 text-slate-300';

                      if (submittedQuiz) {
                        if (isCorrect) {
                          btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-medium';
                        } else if (isChosen && !isCorrect) {
                          btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                        }
                      } else if (isChosen) {
                        btnStyle = 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold shadow-md';
                      }

                      return (
                        <button
                          key={optIdx}
                          disabled={submittedQuiz}
                          onClick={() => handleSelectAnswer(q.id, optIdx)}
                          className={`w-full text-left p-3.5 rounded-xl border text-xs transition-all flex items-start gap-3 ${btnStyle}`}
                        >
                          <span className="font-mono text-xs opacity-70 shrink-0 mt-0.5">
                            {String.fromCharCode(65 + optIdx)}.
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Immediate Feedback when submitted */}
                  {submittedQuiz && (
                    <div className="pt-4 border-t border-slate-800/80 space-y-2">
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1.5">
                        <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider block">
                          Physiological Explanation
                        </span>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {q.explanation}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>Journal Citation: {q.journalCitation}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {!submittedQuiz && (
            <div className="flex justify-end pt-4">
              <button
                onClick={handleSubmitQuiz}
                disabled={Object.keys(selectedAnswers).length < EVALUATION_QUESTIONS.length}
                className="px-6 py-3 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-lg shadow-cyan-500/20"
              >
                Submit Clinical Evaluation ({Object.keys(selectedAnswers).length}/{EVALUATION_QUESTIONS.length} Answered)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Arterial Blood Gas (ABG) Analysis */}
      {activeTab === 'abg' && (
        <div className="space-y-6">
          {/* ABG Case Selector */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {CLINICAL_ABG_CASES.map((abg, idx) => (
              <button
                key={abg.id}
                onClick={() => setSelectedAbgCase(idx)}
                className={`p-4 rounded-2xl text-left border transition-all ${
                  selectedAbgCase === idx
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold shadow-md'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span className={`text-[10px] font-mono uppercase block ${
                  selectedAbgCase === idx ? 'text-slate-950 font-bold' : 'text-cyan-400'
                }`}>
                  ABG Case 0{idx + 1}
                </span>
                <h4 className="text-xs font-bold mt-1">{abg.name}</h4>
              </button>
            ))}
          </div>

          {/* Active ABG Dossier */}
          {(() => {
            const currentAbg = CLINICAL_ABG_CASES[selectedAbgCase];
            return (
              <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                      Point-of-Care Blood Gas Analysis
                    </span>
                    <h3 className="font-display text-xl font-bold text-white mt-1">{currentAbg.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Presentation Vitals: {currentAbg.vitals}</p>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded-lg">
                    Lab Verified
                  </span>
                </div>

                {/* ABG Lab Values 4-Strip */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Arterial pH</span>
                    <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">{currentAbg.ph}</div>
                    <span className="text-[10px] text-slate-500 font-mono">Ref: 7.35 – 7.45</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">PaCO₂</span>
                    <div className="text-2xl font-bold font-mono text-white mt-1">{currentAbg.paco2} <span className="text-xs text-slate-400">mmHg</span></div>
                    <span className="text-[10px] text-slate-500 font-mono">Ref: 35 – 45</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">HCO₃⁻ (Bicarb)</span>
                    <div className="text-2xl font-bold font-mono text-white mt-1">{currentAbg.hco3} <span className="text-xs text-slate-400">mEq/L</span></div>
                    <span className="text-[10px] text-slate-500 font-mono">Ref: 22 – 26</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">PaO₂</span>
                    <div className="text-2xl font-bold font-mono text-white mt-1">{currentAbg.pao2} <span className="text-xs text-slate-400">mmHg</span></div>
                    <span className="text-[10px] text-slate-500 font-mono">Ref: 80 – 100</span>
                  </div>
                </div>

                {/* Diagnostic Interpretation Breakdown */}
                <div className="space-y-4 pt-2">
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider block">
                      Confirmed Primary Diagnosis: {currentAbg.diagnosis}
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentAbg.explanation}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                    <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider block">
                      Recommended Therapeutic Intervention
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentAbg.treatment}
                    </p>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Tab 3: Complete Peer-Reviewed Literature Citations */}
      {activeTab === 'literature' && (
        <div className="space-y-4">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
            <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider block mb-1">
              Peer-Reviewed Scientific Foundation
            </span>
            <p className="text-xs text-slate-300">
              Every numerical model, spirometric cutoff, and biomechanical equation in PulmoLab 3D is strictly sourced from indexed medical literature and respiratory physiology textbooks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {LITERATURE_CITATIONS.map((cit) => (
              <div
                key={cit.id}
                className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-mono text-cyan-400">{cit.year}</span>
                    <span className="font-mono text-slate-500">{cit.doiOrUrl}</span>
                  </div>
                  <h4 className="font-display text-sm font-bold text-white leading-snug">{cit.title}</h4>
                  <p className="text-xs text-slate-400 italic">{cit.authors}</p>
                  <p className="text-xs text-slate-300 leading-relaxed">{cit.summary}</p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex flex-wrap gap-1.5">
                  {cit.keyTopics.map(topic => (
                    <span key={topic} className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {topic}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
