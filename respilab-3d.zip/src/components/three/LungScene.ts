import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export interface LungSceneConfig {
  onOrganSelect?: (organId: string | null) => void;
  isBreathingLab?: boolean;
}

export class LungSceneManager {
  private container: HTMLDivElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private controls!: OrbitControls;
  private animationFrameId: number | null = null;
  private clock: THREE.Clock;
  private isSoftwareGl: boolean = false;
  private isDisposed: boolean = false;

  // Scene Components
  public rootGroup!: THREE.Group;
  public lungsGroup!: THREE.Group;
  public airwayGroup!: THREE.Group;
  public diaphragmGroup!: THREE.Group;
  public ribsGroup!: THREE.Group;
  public alveolarGroup!: THREE.Group;
  public airflowParticles!: THREE.Points;

  // Interactive meshes for raycasting
  private interactiveMeshes: { mesh: THREE.Mesh; organId: string }[] = [];
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private hoveredOrganId: string | null = null;
  private selectedOrganId: string | null = null;
  private onOrganSelect?: (organId: string | null) => void;

  // Breathing & Animation state
  public breathingPhase: number = 0; // 0 to 1 (0: end expiration, 0.5: peak inspiration, 1: end expiration)
  public breathingSpeed: number = 1.0; // multiplier
  public isAutoBreathing: boolean = true;
  public lungOpacity: number = 0.85;
  public explodedDistance: number = 0; // 0 to 1
  public showAirflow: boolean = true;
  public showRibs: boolean = true;
  public showAlveolarMicroView: boolean = false;

  // Materials map for dynamic highlight
  private originalMaterials = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
  private highlightMaterial!: THREE.MeshStandardMaterial;

  // Reusable math vectors to prevent GC
  private _vec3 = new THREE.Vector3();

  constructor(container: HTMLDivElement, config?: LungSceneConfig) {
    this.container = container;
    this.clock = new THREE.Clock();
    this.onOrganSelect = config?.onOrganSelect;
    if (config?.isBreathingLab) {
      this.isAutoBreathing = true;
    }

    this.initWebGL();
    this.setupLightingAndEnvironment();
    this.buildProceduralAnatomy();
    this.buildAirflowParticles();
    this.buildRibcageGrid();
    this.buildAlveolarMicroUnit();
    this.setupInteractivity();
    this.startLoop();
  }

  private initWebGL() {
    // Detect software WebGL per Three.js skill
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 600;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x090d16, 0.025);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.camera.position.set(0, 0.2, 5.8);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.maxDistance = 12;
    this.controls.minDistance = 2.2;
    this.controls.target.set(0, 0.2, 0);

    this.rootGroup = new THREE.Group();
    this.scene.add(this.rootGroup);
  }

  private setupLightingAndEnvironment() {
    // Procedural Studio Environment per Three.js directives
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-point lighting rig
    const keyLight = new THREE.DirectionalLight(0xfff3e0, 2.4);
    keyLight.position.set(4, 6, 4);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.shadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
    }
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    fillLight.position.set(-4, 2, -2);
    this.scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0x06b6d4, 1.6);
    rimLight.position.set(0, -4, -4);
    this.scene.add(rimLight);

    const hemiLight = new THREE.HemisphereLight(0x0ea5e9, 0x090d16, 0.8);
    this.scene.add(hemiLight);

    // Grounding contact shadow plane
    const shadowGeo = new THREE.PlaneGeometry(6, 6);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x020617,
      transparent: true,
      opacity: 0.5,
      depthWrite: false
    });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -2.4;
    this.scene.add(shadowPlane);

    // Highlight material for interactive raycasting
    this.highlightMaterial = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.45,
      roughness: 0.2,
      metalness: 0.1,
      transparent: true,
      opacity: 0.95
    });
  }

  private buildProceduralAnatomy() {
    this.lungsGroup = new THREE.Group();
    this.airwayGroup = new THREE.Group();
    this.diaphragmGroup = new THREE.Group();

    this.rootGroup.add(this.airwayGroup);
    this.rootGroup.add(this.lungsGroup);
    this.rootGroup.add(this.diaphragmGroup);

    // 1. Trachea: Segmented cartilaginous rings and tube
    const tracheaLength = 1.8;
    const tracheaRadius = 0.16;
    const tracheaGeo = new THREE.CylinderGeometry(tracheaRadius, tracheaRadius * 0.95, tracheaLength, 24, 16);
    const tracheaMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.35,
      metalness: 0.05
    });
    const tracheaMesh = new THREE.Mesh(tracheaGeo, tracheaMat);
    tracheaMesh.position.set(0, 1.8, 0);
    this.airwayGroup.add(tracheaMesh);
    this.registerInteractive(tracheaMesh, 'trachea');

    // 12 Cartilaginous C-rings along Trachea
    for (let i = 0; i < 11; i++) {
      const ringGeo = new THREE.TorusGeometry(tracheaRadius * 1.05, 0.022, 12, 24, Math.PI * 1.6);
      const ringMat = new THREE.MeshStandardMaterial({
        color: 0x93c5fd,
        roughness: 0.4,
        metalness: 0.1
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.rotation.z = Math.PI * 0.2;
      ringMesh.position.set(0, 1.0 + i * 0.15, 0);
      this.airwayGroup.add(ringMesh);
    }

    // 2. Carina (Tracheal bifurcation wedge)
    const carinaGeo = new THREE.ConeGeometry(0.18, 0.3, 16);
    const carinaMat = new THREE.MeshStandardMaterial({
      color: 0x60a5fa,
      roughness: 0.3
    });
    const carinaMesh = new THREE.Mesh(carinaGeo, carinaMat);
    carinaMesh.rotation.z = Math.PI;
    carinaMesh.position.set(0, 0.8, 0);
    this.airwayGroup.add(carinaMesh);
    this.registerInteractive(carinaMesh, 'carina');

    // 3. Right & Left Mainstem Bronchi
    // Right: Steeper (25°), wider (~0.13), shorter
    const rightBronchusGeo = new THREE.CylinderGeometry(0.12, 0.09, 0.7, 16);
    const bronchusMat = new THREE.MeshStandardMaterial({
      color: 0x93c5fd,
      roughness: 0.4
    });
    const rightBronchusMesh = new THREE.Mesh(rightBronchusGeo, bronchusMat);
    rightBronchusMesh.position.set(0.28, 0.52, 0);
    rightBronchusMesh.rotation.z = -Math.PI * 0.16; // ~28 degrees
    this.airwayGroup.add(rightBronchusMesh);
    this.registerInteractive(rightBronchusMesh, 'right_bronchus');

    // Left: More angled (45°), narrower (~0.10), longer
    const leftBronchusGeo = new THREE.CylinderGeometry(0.10, 0.08, 0.9, 16);
    const leftBronchusMesh = new THREE.Mesh(leftBronchusGeo, bronchusMat);
    leftBronchusMesh.position.set(-0.35, 0.48, 0);
    leftBronchusMesh.rotation.z = Math.PI * 0.24; // ~43 degrees
    this.airwayGroup.add(leftBronchusMesh);
    this.registerInteractive(leftBronchusMesh, 'left_bronchus');

    // Secondary & Tertiary Bronchial Arborization Tree
    this.buildBronchialBranches(this.airwayGroup);

    // 4. Right Lung (3 Lobes: Superior, Middle, Inferior)
    const rightLungParenchyma = this.createLungLobeGeometry('right');
    const lungMaterialRight = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      roughness: 0.5,
      metalness: 0.05,
      transparent: true,
      opacity: this.lungOpacity,
      depthWrite: true
    });
    const rightLungMesh = new THREE.Mesh(rightLungParenchyma, lungMaterialRight);
    rightLungMesh.position.set(0.95, -0.05, 0);
    this.lungsGroup.add(rightLungMesh);
    this.registerInteractive(rightLungMesh, 'right_lung');

    // 5. Left Lung (2 Lobes + Cardiac notch indentation)
    const leftLungParenchyma = this.createLungLobeGeometry('left');
    const lungMaterialLeft = new THREE.MeshStandardMaterial({
      color: 0xec4899,
      roughness: 0.5,
      metalness: 0.05,
      transparent: true,
      opacity: this.lungOpacity,
      depthWrite: true
    });
    const leftLungMesh = new THREE.Mesh(leftLungParenchyma, lungMaterialLeft);
    leftLungMesh.position.set(-0.95, -0.05, 0);
    this.lungsGroup.add(leftLungMesh);
    this.registerInteractive(leftLungMesh, 'left_lung');

    // 6. Diaphragm Dome (Musculotendinous arch)
    const diaphragmGeo = new THREE.CylinderGeometry(1.9, 2.2, 0.25, 32, 4, false);
    // Deform into realistic dome
    const pos = diaphragmGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const distFromCenter = Math.sqrt(x * x + z * z);
      // Parabolic dome curvature
      const domeRise = Math.max(0, 0.5 - distFromCenter * 0.22);
      pos.setY(i, pos.getY(i) + domeRise);
    }
    diaphragmGeo.computeVertexNormals();

    const diaphragmMat = new THREE.MeshStandardMaterial({
      color: 0xe11d48,
      roughness: 0.6,
      metalness: 0.02
    });
    const diaphragmMesh = new THREE.Mesh(diaphragmGeo, diaphragmMat);
    diaphragmMesh.position.set(0, -1.5, 0);
    this.diaphragmGroup.add(diaphragmMesh);
    this.registerInteractive(diaphragmMesh, 'diaphragm');

    // Central tendon of diaphragm (aponeurotic sheet)
    const tendonGeo = new THREE.CircleGeometry(0.85, 24);
    const tendonMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.35,
      side: THREE.DoubleSide
    });
    const tendonMesh = new THREE.Mesh(tendonGeo, tendonMat);
    tendonMesh.rotation.x = -Math.PI / 2;
    tendonMesh.position.set(0, -1.25, 0);
    this.diaphragmGroup.add(tendonMesh);

    // 7. Pleural Space & Membrane Boundary (Subtle semi-transparent sheath)
    const pleuraGeo = new THREE.SphereGeometry(1.95, 24, 24);
    pleuraGeo.scale(1.2, 1.1, 0.85);
    const pleuraMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
      roughness: 0.1,
      metalness: 0.1,
      transmission: this.isSoftwareGl ? 0 : 0.85,
      ior: 1.33,
      depthWrite: false
    });
    const pleuraMesh = new THREE.Mesh(pleuraGeo, pleuraMat);
    pleuraMesh.position.set(0, -0.1, 0);
    this.rootGroup.add(pleuraMesh);
    this.registerInteractive(pleuraMesh, 'pleura');
  }

  private createLungLobeGeometry(side: 'right' | 'left'): THREE.BufferGeometry {
    // Generate organic multi-lobar lung geometry using customized sphere deformation
    const geo = new THREE.SphereGeometry(1.05, 36, 36);
    const pos = geo.attributes.position;

    for (let i = 0; i < pos.count; i++) {
      let x = pos.getX(i);
      let y = pos.getY(i);
      let z = pos.getZ(i);

      // Anatomical vertical tapering (apex is narrow, base is wide and concaved by diaphragm)
      const apexFactor = 1.0 - (y + 1.0) * 0.15;
      x *= apexFactor;
      z *= apexFactor * 0.85;

      // Vertical stretch
      y *= 1.35;

      // Base concave curve for diaphragm fit
      if (y < -0.6) {
        y += 0.25 * (1.0 - Math.sqrt(x * x + z * z));
      }

      // Medial flattening and cardiac notch (Left lung)
      if (side === 'left') {
        if (x > -0.2 && y > -0.5 && y < 0.4 && z > 0) {
          // Cardiac notch excavation
          x -= 0.35 * Math.sin((y + 0.5) * Math.PI);
        }
      } else {
        // Right lung is broader with 3 lobes
        x *= 1.12;
      }

      pos.setXYZ(i, x, y, z);
    }

    geo.computeVertexNormals();
    return geo;
  }

  private buildBronchialBranches(parent: THREE.Group) {
    const branchMat = new THREE.MeshStandardMaterial({
      color: 0xbae6fd,
      roughness: 0.35
    });

    const branches = [
      // Right Superior, Middle, Inferior Lobar bronchi
      { pos: [0.65, 0.45, 0.15], rot: [-0.3, 0.2, -0.6], scale: [0.06, 0.45, 0.06] },
      { pos: [0.75, 0.15, 0.25], rot: [0.2, 0.4, -0.8], scale: [0.05, 0.4, 0.05] },
      { pos: [0.6, -0.2, -0.1], rot: [0.4, -0.2, -0.3], scale: [0.055, 0.55, 0.055] },
      { pos: [0.85, -0.45, 0.1], rot: [0.1, 0.3, -0.4], scale: [0.04, 0.35, 0.04] },
      // Left Superior & Inferior Lobar bronchi
      { pos: [-0.65, 0.45, 0.1], rot: [-0.2, -0.2, 0.6], scale: [0.06, 0.45, 0.06] },
      { pos: [-0.75, 0.05, 0.2], rot: [0.3, -0.4, 0.7], scale: [0.05, 0.42, 0.05] },
      { pos: [-0.65, -0.3, -0.1], rot: [0.4, 0.2, 0.35], scale: [0.05, 0.5, 0.05] },
      { pos: [-0.85, -0.55, 0.15], rot: [0.1, -0.3, 0.4], scale: [0.038, 0.35, 0.038] }
    ];

    branches.forEach(b => {
      const geo = new THREE.CylinderGeometry(1, 0.7, 1, 10);
      const mesh = new THREE.Mesh(geo, branchMat);
      mesh.position.set(b.pos[0], b.pos[1], b.pos[2]);
      mesh.rotation.set(b.rot[0], b.rot[1], b.rot[2]);
      mesh.scale.set(b.scale[0], b.scale[1], b.scale[2]);
      parent.add(mesh);
    });
  }

  private buildAirflowParticles() {
    const particleCount = 280;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Distribute particles along airway flow paths
      const t = Math.random();
      let x = 0;
      let y = 2.6 - t * 2.8;
      let z = (Math.random() - 0.5) * 0.15;

      if (y < 0.8) {
        // Bifurcate to right or left
        const side = Math.random() > 0.5 ? 1 : -1;
        x = side * (0.8 - y) * 0.8 + (Math.random() - 0.5) * 0.3;
        z += (Math.random() - 0.5) * 0.2;
      } else {
        x = (Math.random() - 0.5) * 0.12;
      }

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      // Cyan oxygenated particle color
      colors[i * 3] = 0.22;
      colors[i * 3 + 1] = 0.74;
      colors[i * 3 + 2] = 0.97;
    }

    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending
    });

    this.airflowParticles = new THREE.Points(particleGeo, particleMat);
    this.rootGroup.add(this.airflowParticles);
  }

  private buildRibcageGrid() {
    this.ribsGroup = new THREE.Group();
    const ribMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.3,
      metalness: 0.1,
      transparent: true,
      opacity: 0.35
    });

    // 7 pairs of true procedural ribs wrapping around the thoracic cage
    for (let i = 0; i < 7; i++) {
      const yLevel = 1.0 - i * 0.38;
      const radiusX = 1.6 + i * 0.08;
      const radiusZ = 1.1 + i * 0.05;

      const curve = new THREE.EllipseCurve(
        0, 0,
        radiusX, radiusZ,
        0, Math.PI * 2,
        false, 0
      );
      const points = curve.getPoints(36);
      const ribGeo = new THREE.BufferGeometry().setFromPoints(points);
      const ribLine = new THREE.Line(ribGeo, new THREE.LineBasicMaterial({
        color: 0x64748b,
        transparent: true,
        opacity: 0.45
      }));
      ribLine.rotation.x = Math.PI / 2 + (i * 0.05); // slight bucket handle downward tilt
      ribLine.position.set(0, yLevel, 0);
      this.ribsGroup.add(ribLine);
    }

    this.rootGroup.add(this.ribsGroup);
  }

  private buildAlveolarMicroUnit() {
    this.alveolarGroup = new THREE.Group();
    this.alveolarGroup.position.set(0, 0, 0);
    this.alveolarGroup.visible = false;

    // Cluster of microscopic alveolar spheres surrounded by capillary mesh
    const alveolusMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.4,
      metalness: 0.1,
      transparent: true,
      opacity: 0.9
    });

    // Center primary alveolar cluster
    for (let i = 0; i < 14; i++) {
      const r = 0.28 + Math.random() * 0.1;
      const sphereGeo = new THREE.SphereGeometry(r, 18, 18);
      const sphereMesh = new THREE.Mesh(sphereGeo, alveolusMat);

      const phi = Math.random() * Math.PI * 2;
      const theta = Math.random() * Math.PI;
      const dist = 0.35 + Math.random() * 0.25;

      sphereMesh.position.set(
        dist * Math.sin(theta) * Math.cos(phi),
        dist * Math.sin(theta) * Math.sin(phi),
        dist * Math.cos(theta)
      );
      this.alveolarGroup.add(sphereMesh);
    }

    // Capillary network lines (Red for oxygenated, Blue for deoxygenated)
    const capillaryPoints: THREE.Vector3[] = [];
    for (let c = 0; c < 30; c++) {
      const v = new THREE.Vector3(
        (Math.random() - 0.5) * 1.4,
        (Math.random() - 0.5) * 1.4,
        (Math.random() - 0.5) * 1.4
      );
      capillaryPoints.push(v);
    }
    const capGeo = new THREE.BufferGeometry().setFromPoints(capillaryPoints);
    const capLine = new THREE.LineSegments(capGeo, new THREE.LineBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.7
    }));
    this.alveolarGroup.add(capLine);

    this.rootGroup.add(this.alveolarGroup);
  }

  private registerInteractive(mesh: THREE.Mesh, organId: string) {
    this.interactiveMeshes.push({ mesh, organId });
    this.originalMaterials.set(mesh, mesh.material);
  }

  private setupInteractivity() {
    const onPointerMove = (e: MouseEvent) => {
      const rect = this.container.getBoundingClientRect();
      this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const targets = this.interactiveMeshes.map(m => m.mesh);
      const intersects = this.raycaster.intersectObjects(targets, false);

      if (intersects.length > 0) {
        const hit = intersects[0].object as THREE.Mesh;
        const entry = this.interactiveMeshes.find(m => m.mesh === hit);
        if (entry && entry.organId !== this.hoveredOrganId) {
          this.hoveredOrganId = entry.organId;
          this.container.style.cursor = 'pointer';
        }
      } else {
        if (this.hoveredOrganId !== null) {
          this.hoveredOrganId = null;
          this.container.style.cursor = 'default';
        }
      }
    };

    const onClick = (e: MouseEvent) => {
      const rect = this.container.getBoundingClientRect();
      this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const targets = this.interactiveMeshes.map(m => m.mesh);
      const intersects = this.raycaster.intersectObjects(targets, false);

      if (intersects.length > 0) {
        const hit = intersects[0].object as THREE.Mesh;
        const entry = this.interactiveMeshes.find(m => m.mesh === hit);
        if (entry) {
          this.setSelectedOrgan(entry.organId);
          if (this.onOrganSelect) {
            this.onOrganSelect(entry.organId);
          }
        }
      } else {
        this.setSelectedOrgan(null);
        if (this.onOrganSelect) {
          this.onOrganSelect(null);
        }
      }
    };

    this.container.addEventListener('pointermove', onPointerMove);
    this.container.addEventListener('click', onClick);
  }

  public setSelectedOrgan(organId: string | null) {
    this.selectedOrganId = organId;

    // Reset all original materials
    this.interactiveMeshes.forEach(entry => {
      const original = this.originalMaterials.get(entry.mesh);
      if (original) {
        entry.mesh.material = original;
      }
    });

    if (organId) {
      const target = this.interactiveMeshes.find(m => m.organId === organId);
      if (target) {
        target.mesh.material = this.highlightMaterial;
      }
    }
  }

  public setExplodedDistance(val: number) {
    this.explodedDistance = val;
    // Animate exploded positions
    const rightLung = this.interactiveMeshes.find(m => m.organId === 'right_lung')?.mesh;
    const leftLung = this.interactiveMeshes.find(m => m.organId === 'left_lung')?.mesh;
    const diaphragm = this.interactiveMeshes.find(m => m.organId === 'diaphragm')?.mesh;

    if (rightLung) {
      rightLung.position.x = 0.95 + val * 0.8;
      rightLung.position.z = val * 0.4;
    }
    if (leftLung) {
      leftLung.position.x = -0.95 - val * 0.8;
      leftLung.position.z = val * 0.4;
    }
    if (diaphragm) {
      diaphragm.position.y = -1.5 - val * 0.7;
    }
  }

  public setLungOpacity(val: number) {
    this.lungOpacity = val;
    const rightLung = this.interactiveMeshes.find(m => m.organId === 'right_lung')?.mesh;
    const leftLung = this.interactiveMeshes.find(m => m.organId === 'left_lung')?.mesh;

    if (rightLung && rightLung.material instanceof THREE.MeshStandardMaterial) {
      rightLung.material.opacity = val;
      rightLung.material.transparent = val < 0.99;
    }
    if (leftLung && leftLung.material instanceof THREE.MeshStandardMaterial) {
      leftLung.material.opacity = val;
      leftLung.material.transparent = val < 0.99;
    }
  }

  public setCameraPreset(preset: 'anterior' | 'posterior' | 'lateral' | 'alveolar' | 'diaphragm') {
    switch (preset) {
      case 'anterior':
        this.camera.position.set(0, 0.2, 5.8);
        this.controls.target.set(0, 0.2, 0);
        this.alveolarGroup.visible = false;
        this.lungsGroup.visible = true;
        this.airwayGroup.visible = true;
        break;
      case 'posterior':
        this.camera.position.set(0, 0.2, -5.8);
        this.controls.target.set(0, 0.2, 0);
        this.alveolarGroup.visible = false;
        this.lungsGroup.visible = true;
        this.airwayGroup.visible = true;
        break;
      case 'lateral':
        this.camera.position.set(5.5, 0.1, 0);
        this.controls.target.set(0, 0.1, 0);
        this.alveolarGroup.visible = false;
        this.lungsGroup.visible = true;
        this.airwayGroup.visible = true;
        break;
      case 'alveolar':
        this.camera.position.set(0, 0, 1.8);
        this.controls.target.set(0, 0, 0);
        this.alveolarGroup.visible = true;
        this.lungsGroup.visible = false;
        this.airwayGroup.visible = false;
        break;
      case 'diaphragm':
        this.camera.position.set(0, -3.2, 3.5);
        this.controls.target.set(0, -1.5, 0);
        this.alveolarGroup.visible = false;
        this.lungsGroup.visible = true;
        this.airwayGroup.visible = true;
        break;
    }
  }

  private startLoop() {
    let frameId = 0;

    const afterDraw = (cb: () => void) => {
      const gl = this.renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (this.isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (this.isDisposed) return;

      const delta = this.clock.getDelta();
      const elapsedTime = this.clock.getElapsedTime();

      // Breathing mechanics kinematics
      if (this.isAutoBreathing) {
        // Sinusoidal ventilation rhythm
        this.breathingPhase = (Math.sin(elapsedTime * 1.8 * this.breathingSpeed) + 1) / 2;
      }

      // 1. Lung expansion: Volume expands by 12% - 25% during inspiration
      const lungExpansion = 1.0 + this.breathingPhase * 0.16;
      this.lungsGroup.scale.set(lungExpansion, 1.0 + this.breathingPhase * 0.12, lungExpansion);

      // 2. Diaphragmatic descent: moves downwards 0.35 units during inspiration
      this.diaphragmGroup.position.y = -this.breathingPhase * 0.35;

      // 3. Ribcage bucket-handle expansion
      if (this.ribsGroup) {
        const ribExpansion = 1.0 + this.breathingPhase * 0.08;
        this.ribsGroup.scale.set(ribExpansion, 1.0, ribExpansion);
      }

      // 4. Airflow particle flow animation
      if (this.airflowParticles && this.showAirflow) {
        const positions = this.airflowParticles.geometry.attributes.position.array as Float32Array;
        const colors = this.airflowParticles.geometry.attributes.color.array as Float32Array;
        const isInspiratory = Math.cos(elapsedTime * 1.8 * this.breathingSpeed) > 0;

        for (let i = 0; i < positions.length / 3; i++) {
          const idx = i * 3;
          if (isInspiratory) {
            // Flow downward into lungs
            positions[idx + 1] -= 0.04;
            if (positions[idx + 1] < -1.4) {
              positions[idx + 1] = 2.4;
              positions[idx] = (Math.random() - 0.5) * 0.15;
            }
            // Cyan oxygenated color
            colors[idx] = 0.22;
            colors[idx + 1] = 0.74;
            colors[idx + 2] = 0.97;
          } else {
            // Exhale upward out of lungs
            positions[idx + 1] += 0.04;
            if (positions[idx + 1] > 2.4) {
              positions[idx + 1] = -1.4;
              const side = Math.random() > 0.5 ? 1 : -1;
              positions[idx] = side * (0.6 + Math.random() * 0.4);
            }
            // Amber CO2-rich color
            colors[idx] = 0.96;
            colors[idx + 1] = 0.62;
            colors[idx + 2] = 0.22;
          }
        }
        this.airflowParticles.geometry.attributes.position.needsUpdate = true;
        this.airflowParticles.geometry.attributes.color.needsUpdate = true;
      }

      // Smooth controls damping
      this.controls.update();
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        afterDraw(tick);
      } else {
        this.animationFrameId = requestAnimationFrame(tick);
      }
    };

    tick();
  }

  public handleResize() {
    if (!this.container || this.isDisposed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width === 0 || height === 0) return;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public dispose() {
    this.isDisposed = true;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.controls.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
