import React, { useState } from 'react';
import { CASE_STUDIES } from '../data/caseScenarios';
import { LabStage } from '../types/respiratory';
import { 
  User, 
  Heart, 
  Wind, 
  Activity, 
  Thermometer, 
  CheckCircle2, 
  Circle, 
  ArrowRight,
  BookOpen,
  ClipboardList,
  AlertCircle
} from 'lucide-react';

interface InvestigationCaseProps {
  onSelectStage: (stage: LabStage) => void;
  completedStages: LabStage[];
}

export const InvestigationCase: React.FC<InvestigationCaseProps> = ({
  onSelectStage,
  completedStages
}) => {
  const [activeCaseIndex, setActiveCaseIndex] = useState(0);
  const currentCase = CASE_STUDIES[activeCaseIndex];

  return (
    <div className="space-y-8 py-6">
      {/* Header and Case Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 02 · Clinical Case Briefing</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Research Scenario &amp; Investigation Missions</h2>
        </div>

        {/* Case Selector Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          {CASE_STUDIES.map((c, idx) => (
            <button
              key={c.id}
              onClick={() => setActiveCaseIndex(idx)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                activeCaseIndex === idx
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {idx === 0 ? 'Case #RP-402 (Athlete)' : 'Case #RP-108 (Dyspnea)'}
            </button>
          ))}
        </div>
      </div>

      {/* Patient Dossier & Live Vitals Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Clinical History & Hypotheses */}
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-white">{currentCase.patient.name}</h3>
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span>{currentCase.patient.age} y/o</span>
                    <span aria-hidden="true">·</span>
                    <span>{currentCase.patient.sex}</span>
                    <span aria-hidden="true">·</span>
                    <span>{currentCase.patient.occupation}</span>
                  </div>
                </div>
              </div>

              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2.5 py-1 rounded-md">
                Case Status: Open Investigation
              </span>
            </div>

            <div className="space-y-3 pt-2 text-sm">
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                <span className="text-xs font-semibold text-rose-400 uppercase tracking-wider block mb-1">
                  Chief Complaint
                </span>
                <p className="text-slate-200 italic font-medium">{currentCase.patient.chiefComplaint}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  History of Present Illness (HPI)
                </span>
                <p className="text-slate-300 leading-relaxed text-xs">
                  {currentCase.patient.historyOfPresentIllness}
                </p>
              </div>
            </div>
          </div>

          {/* Differential Diagnostic Hypotheses */}
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
              <AlertCircle className="w-4 h-4 text-cyan-400" />
              <span>Differential Clinical Hypotheses</span>
            </div>
            <div className="space-y-2">
              {currentCase.clinicalHypotheses.map((hyp, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300"
                >
                  <span className="font-mono text-cyan-400 font-semibold shrink-0">H{i + 1}</span>
                  <span>{hyp}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex items-center gap-2 text-xs text-slate-400">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>Evidence Source: {currentCase.journalSource}</span>
            </div>
          </div>
        </div>

        {/* Right Col: Live Clinical Vitals & Lab Missions */}
        <div className="space-y-6">
          {/* Vitals Telemetry Card */}
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Baseline Patient Vitals
              </span>
              <span className="text-xs font-mono text-emerald-400">STABLE</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  <span>Heart Rate</span>
                </div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {currentCase.patient.vitals.heartRate} <span className="text-xs font-normal text-slate-400">bpm</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Wind className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Resp. Rate</span>
                </div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {currentCase.patient.vitals.respiratoryRate} <span className="text-xs font-normal text-slate-400">bpm</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Activity className="w-3.5 h-3.5 text-amber-400" />
                  <span>Blood Press.</span>
                </div>
                <div className="text-sm font-bold font-mono text-white mt-1.5">
                  {currentCase.patient.vitals.bloodPressure}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Thermometer className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Oxygen Sat.</span>
                </div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {currentCase.patient.vitals.spO2}% <span className="text-xs font-normal text-slate-400">SpO2</span>
                </div>
              </div>
            </div>
          </div>

          {/* Research Investigation Missions */}
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ClipboardList className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                  Investigation Checklist
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {completedStages.filter(s => currentCase.investigationMissions.some(m => m.targetStage === s)).length} / {currentCase.investigationMissions.length} Done
              </span>
            </div>

            <div className="space-y-2.5">
              {currentCase.investigationMissions.map((mission) => {
                const isDone = completedStages.includes(mission.targetStage);

                return (
                  <div
                    key={mission.id}
                    onClick={() => onSelectStage(mission.targetStage)}
                    className="group cursor-pointer p-3 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-cyan-500/40 transition-colors flex items-start gap-3"
                  >
                    <div className="mt-0.5 shrink-0">
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 transition-colors" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors truncate">
                          {mission.title}
                        </h4>
                        <span className="text-[10px] uppercase font-mono text-cyan-400 ml-2 shrink-0">
                          {mission.targetStage}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                        {mission.objective}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => onSelectStage('anatomy')}
              className="w-full flex items-center justify-center gap-2 py-3 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold transition-colors mt-2"
            >
              <span>Launch Mission 01: Anatomy Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
