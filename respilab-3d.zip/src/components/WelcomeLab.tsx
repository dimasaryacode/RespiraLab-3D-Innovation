import React from 'react';
import { LabStage } from '../types/respiratory';
import { LAB_STAGES } from '../data/stagesData';
import { 
  Activity, 
  Layers, 
  Wind, 
  Gauge, 
  FlaskConical, 
  BarChart3, 
  Wrench, 
  GraduationCap, 
  FileText, 
  ShieldCheck, 
  ArrowRight,
  BookOpen
} from 'lucide-react';

interface WelcomeLabProps {
  onStart: () => void;
  onSelectStage: (stage: LabStage) => void;
}

export const WelcomeLab: React.FC<WelcomeLabProps> = ({ onStart, onSelectStage }) => {
  const stationIcons: Record<string, React.ReactNode> = {
    welcome: <Activity className="w-5 h-5 text-cyan-400" />,
    case: <FileText className="w-5 h-5 text-cyan-400" />,
    anatomy: <Layers className="w-5 h-5 text-cyan-400" />,
    breathing: <Wind className="w-5 h-5 text-cyan-400" />,
    spirometry: <Gauge className="w-5 h-5 text-cyan-400" />,
    rate: <FlaskConical className="w-5 h-5 text-cyan-400" />,
    analysis: <BarChart3 className="w-5 h-5 text-cyan-400" />,
    engineering: <Wrench className="w-5 h-5 text-cyan-400" />,
    evaluation: <GraduationCap className="w-5 h-5 text-cyan-400" />,
  };

  return (
    <div className="space-y-12 py-6">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 md:p-12">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-3xl space-y-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-widest">
            <span>Institute of Respiratory Biomechanics</span>
            <span aria-hidden="true">·</span>
            <span>Virtual Physiology Lab</span>
          </div>

          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Advanced 3D Pulmonary <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-teal-300">
              Mechanics & Physiology Lab
            </span>
          </h1>

          <p className="text-base md:text-lg text-slate-300 leading-relaxed">
            Welcome to PulmoLab 3D, a comprehensive research-grade virtual laboratory for respiratory mechanics, clinical spirometry, gas exchange calculations, and thoracic bioengineering. Built on peer-reviewed guidelines from the American Thoracic Society (ATS), European Respiratory Society (ERS), and Guyton &amp; Hall Medical Physiology.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={onStart}
              className="flex items-center gap-2.5 px-6 py-3.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-sm rounded-xl transition-all shadow-lg shadow-cyan-500/20"
            >
              <span>Begin Investigation (Case #RP-402)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSelectStage('anatomy')}
              className="flex items-center gap-2 px-5 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-medium text-sm rounded-xl transition-colors"
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Explore 3D Anatomy</span>
            </button>
          </div>

          <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-slate-400 border-t border-slate-800/80">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>ATS/ERS 2019 Spirometry Standardized</span>
            </div>
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span>West's Respiratory Physiology Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-cyan-300">ISO-26782 Compliance</span>
            </div>
          </div>
        </div>
      </section>

      {/* 9 Stages Interactive Grid */}
      <section className="space-y-6">
        <div className="flex items-end justify-between border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Laboratory Curriculum</span>
            <h2 className="font-display text-2xl font-bold text-white mt-1">Nine Sequential Research Stations</h2>
          </div>
          <p className="text-xs text-slate-400 max-w-md hidden md:block">
            Step through clinical inquiry, anatomical dissection, real-time biomechanics, dynamic spirometry, physical model assembly, and board-level evaluation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {LAB_STAGES.map((stage) => (
            <div
              key={stage.id}
              onClick={() => onSelectStage(stage.id)}
              className="group cursor-pointer rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-cyan-500/50 p-6 transition-all duration-200 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center group-hover:border-cyan-500/40 transition-colors">
                    {stationIcons[stage.id]}
                  </div>
                  <span className="text-xs font-mono text-slate-400 group-hover:text-cyan-400 transition-colors">
                    0{stage.number}
                  </span>
                </div>

                <div>
                  <h3 className="font-display text-lg font-semibold text-white group-hover:text-cyan-300 transition-colors">
                    {stage.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {stage.description}
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800/60 flex items-center justify-between text-xs font-medium text-slate-400 group-hover:text-cyan-400 transition-colors">
                <span>Enter Station</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Lab Instrumentation & Equipment Overview */}
      <section className="rounded-2xl bg-slate-900/40 border border-slate-800 p-8 space-y-6">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Laboratory Infrastructure</span>
          <h2 className="font-display text-xl font-bold text-white mt-1">Calibrated Experimental Equipment</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <h4 className="font-semibold text-slate-200 text-sm">3D High-Res Organ Scanner</h4>
            <p className="text-slate-400">
              Procedural WebGL rendering of Trachea, Carina, 5 Lobes, Pleural Cavity, and Alveolar units with sub-millimeter precision.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <h4 className="font-semibold text-slate-200 text-sm">Fleisch Pneumotachograph</h4>
            <p className="text-slate-400">
              Differential pressure transducer measuring flow rate and integrating real-time volume during forced expiratory maneuvers.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <h4 className="font-semibold text-slate-200 text-sm">Hypobaric Altitude Simulator</h4>
            <p className="text-slate-400">
              Pressure chamber capable of simulating sea level (760 mmHg) up to Everest Base Camp (380 mmHg) for hypoxic drive studies.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <h4 className="font-semibold text-slate-200 text-sm">Biomimetic Thorax Rig</h4>
            <p className="text-slate-400">
              Airtight glass chamber with rubber diaphragm actuator and U-tube water manometer to physically validate Boyle's law.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
