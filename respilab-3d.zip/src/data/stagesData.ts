import { StageInfo } from '../types/respiratory';

export const LAB_STAGES: StageInfo[] = [
  {
    id: 'welcome',
    number: 1,
    title: 'Welcome Lab',
    shortTitle: '1. Welcome',
    description: 'Laboratory orientation, equipment overview, and bio-safety identity.',
    badge: 'Station 01'
  },
  {
    id: 'case',
    number: 2,
    title: 'Investigation Case',
    shortTitle: '2. Case Study',
    description: 'Clinical problem scenario, patient vitals, and research investigation missions.',
    badge: 'Station 02'
  },
  {
    id: 'anatomy',
    number: 3,
    title: 'Anatomy Lab',
    shortTitle: '3. 3D Anatomy',
    description: 'Interactive 3D anatomical exploration of airways, lung lobes, pleura, and alveolar units.',
    badge: 'Station 03'
  },
  {
    id: 'breathing',
    number: 4,
    title: 'Breathing Lab',
    shortTitle: '4. Biomechanics',
    description: 'Inspiration-expiration 3D mechanics with muscle dynamics, airflow vectors, and Boyle’s law.',
    badge: 'Station 04'
  },
  {
    id: 'spirometry',
    number: 5,
    title: 'Spirometry Lab',
    shortTitle: '5. Spirometry',
    description: 'Interactive breath maneuvers, Volume-Time and Flow-Volume curves based on ATS/ERS standards.',
    badge: 'Station 05'
  },
  {
    id: 'rate',
    number: 6,
    title: 'Respiratory Rate Lab',
    shortTitle: '6. Rate Dynamics',
    description: 'Comparative experiments on age, physical exertion, altitude hypoxia, and pathology.',
    badge: 'Station 06'
  },
  {
    id: 'analysis',
    number: 7,
    title: 'Data Analysis',
    shortTitle: '7. Data Analysis',
    description: 'Physiological computation: minute ventilation, alveolar ventilation, and gas diffusion curves.',
    badge: 'Station 07'
  },
  {
    id: 'engineering',
    number: 8,
    title: 'Engineering Challenge',
    shortTitle: '8. Model Assembly',
    description: 'Drag-and-drop assembly of the biomimetic thoracic bell-jar model and interactive pressure test.',
    badge: 'Station 08'
  },
  {
    id: 'evaluation',
    number: 9,
    title: 'Evaluation',
    shortTitle: '9. Evaluation',
    description: 'Comprehensive clinical evaluation, arterial blood gas reasoning, and peer-reviewed certification.',
    badge: 'Station 09'
  }
];
