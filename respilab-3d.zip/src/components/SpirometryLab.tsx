import React, { useState, useEffect, useRef } from 'react';
import { LabStage, SpirometryDataPoint, SpirometryResult } from '../types/respiratory';
import { 
  Gauge, 
  Wind, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight,
  TrendingUp,
  BookOpen
} from 'lucide-react';

interface SpirometryLabProps {
  onCompleteMission?: () => void;
  onNextStage?: (stage: LabStage) => void;
}

export const SpirometryLab: React.FC<SpirometryLabProps> = ({
  onCompleteMission,
  onNextStage
}) => {
  const [selectedProfile, setSelectedProfile] = useState<'normal' | 'obstructive_eib' | 'copd' | 'restrictive'>('normal');
  const [testPhase, setTestPhase] = useState<'idle' | 'inhaling' | 'blasting' | 'completed'>('idle');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [curvePoints, setCurvePoints] = useState<SpirometryDataPoint[]>([]);
  const animationTimerRef = useRef<number | null>(null);

  // Profile presets based on clinical ATS/ERS guidelines
  const profiles = {
    normal: {
      name: 'Healthy Normal Subject',
      description: 'Standard adult reference. Rapid initial blast, FEV1 > 80% of FVC.',
      fvc: 4.8, // L
      fev1: 4.0, // L
      pef: 9.8, // L/s
      rv: 1.2, // L
      erv: 1.1, // L
      vt: 0.5, // L
      irv: 3.2, // L
      pattern: 'Normal' as const,
      ratio: 83.3,
      scoopFactor: 1.0 // 1.0 = linear descending limb
    },
    obstructive_eib: {
      name: 'Marcus Vance: Post-Sprint EIB',
      description: 'Exercise-induced bronchoconstriction. Lowered FEV1/FVC ratio with scooped expiratory curve.',
      fvc: 4.5,
      fev1: 2.5,
      pef: 6.2,
      rv: 1.6,
      erv: 1.0,
      vt: 0.5,
      irv: 3.0,
      pattern: 'Obstructive (Mild)' as const,
      ratio: 55.6,
      scoopFactor: 0.45 // concavity
    },
    copd: {
      name: 'Severe Chronic COPD',
      description: 'Severe airway limitation and air trapping. Pronounced scooped flow-volume loop, FEV1/FVC < 50%.',
      fvc: 3.2,
      fev1: 1.4,
      pef: 4.1,
      rv: 2.8,
      erv: 0.6,
      vt: 0.45,
      irv: 2.15,
      pattern: 'Obstructive (Severe)' as const,
      ratio: 43.8,
      scoopFactor: 0.25
    },
    restrictive: {
      name: 'Eleanor Vance: Pulmonary Fibrosis',
      description: 'Stiff lungs with decreased compliance. Reduced FVC, but preserved or elevated FEV1/FVC ratio > 85%.',
      fvc: 2.6,
      fev1: 2.3,
      pef: 7.2,
      rv: 0.8,
      erv: 0.6,
      vt: 0.35,
      irv: 1.65,
      pattern: 'Restrictive' as const,
      ratio: 88.5,
      scoopFactor: 1.1
    }
  };

  const activeP = profiles[selectedProfile];

  // Run Spirometry Maneuver Simulation
  const startSpirometryTest = () => {
    if (animationTimerRef.current) cancelAnimationFrame(animationTimerRef.current);
    setTestPhase('inhaling');
    setCurrentTime(0);
    setCurvePoints([]);

    const startTime = performance.now();
    const duration = 6500; // 6.5s ATS maneuver duration

    const updateFrame = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      setCurrentTime(elapsed);

      // Phase 1: Inhale to TLC (0 to 1.5s)
      if (elapsed < 1.5) {
        setTestPhase('inhaling');
      } else if (elapsed >= 1.5 && elapsed < 6.0) {
        // Phase 2: FORCED EXPIRATORY BLAST
        setTestPhase('blasting');
      } else {
        setTestPhase('completed');
      }

      // Compute instantaneous volume and flow
      const tBlast = Math.max(0, elapsed - 1.5);
      let vol = 0;
      let flow = 0;

      if (tBlast > 0) {
        // Exponential forced expiratory curve: V(t) = FVC * (1 - exp(-k * t))
        const k = (activeP.fev1 / activeP.fvc) * 2.8;
        vol = activeP.fvc * (1 - Math.exp(-k * tBlast));

        // Flow is derivative dV/dt (in L/s)
        if (tBlast < 0.15) {
          flow = (tBlast / 0.15) * activeP.pef; // rapid rise to PEF in ~120ms
        } else {
          // Descending limb with scoop factor
          const remainingFraction = Math.max(0, 1 - (vol / activeP.fvc));
          flow = activeP.pef * Math.pow(remainingFraction, 1 / activeP.scoopFactor);
        }
      }

      setCurvePoints(prev => [...prev, { time: elapsed, volume: vol, flow: flow }]);

      if (elapsed < 6.2) {
        animationTimerRef.current = requestAnimationFrame(updateFrame);
      } else {
        setTestPhase('completed');
      }
    };

    animationTimerRef.current = requestAnimationFrame(updateFrame);
  };

  const resetTest = () => {
    if (animationTimerRef.current) cancelAnimationFrame(animationTimerRef.current);
    setTestPhase('idle');
    setCurrentTime(0);
    setCurvePoints([]);
  };

  useEffect(() => {
    return () => {
      if (animationTimerRef.current) cancelAnimationFrame(animationTimerRef.current);
    };
  }, []);

  // Pre-fill initial static curve for inspection if idle
  const displayPoints = curvePoints.length > 0 ? curvePoints : generateStaticCurve(activeP);

  function generateStaticCurve(p: typeof activeP): SpirometryDataPoint[] {
    const pts: SpirometryDataPoint[] = [];
    const k = (p.fev1 / p.fvc) * 2.8;
    for (let t = 0; t <= 4.5; t += 0.05) {
      const vol = p.fvc * (1 - Math.exp(-k * t));
      let flow = 0;
      if (t < 0.15) {
        flow = (t / 0.15) * p.pef;
      } else {
        const remainingFraction = Math.max(0, 1 - (vol / p.fvc));
        flow = p.pef * Math.pow(remainingFraction, 1 / p.scoopFactor);
      }
      pts.push({ time: t + 1.5, volume: vol, flow });
    }
    return pts;
  }

  // SVG dimensions for chart
  const chartW = 440;
  const chartH = 220;
  const maxTime = 6.0;
  const maxVol = 6.0;
  const maxFlow = 11.0;

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 05 · Clinical Pulmonary Function Testing</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Spirometry Lab &amp; Flow-Volume Dynamics</h2>
        </div>

        <div className="flex items-center gap-3">
          {/* Profile Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
            {(['normal', 'obstructive_eib', 'copd', 'restrictive'] as const).map(pKey => (
              <button
                key={pKey}
                onClick={() => {
                  setSelectedProfile(pKey);
                  resetTest();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  selectedProfile === pKey
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {pKey === 'normal' ? 'Normal' : pKey === 'obstructive_eib' ? 'EIB (Marcus)' : pKey === 'copd' ? 'COPD' : 'Restrictive'}
              </button>
            ))}
          </div>

          {onNextStage && (
            <button
              onClick={() => {
                if (onCompleteMission) onCompleteMission();
                onNextStage('rate');
              }}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Rate Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Interactive Spirometer Mouthpiece + Dynamic Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column (5 cols): Interactive Mouthpiece & ATS Criteria */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          {/* Patient Profile Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">Test Subject Profile</span>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                activeP.pattern === 'Normal'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
              }`}>
                {activeP.pattern} Pattern
              </span>
            </div>
            <h3 className="font-display text-lg font-bold text-white">{activeP.name}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{activeP.description}</p>
          </div>

          {/* Virtual Spirometer Mouthpiece Controller */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between items-center text-center space-y-5">
            <div className="w-20 h-20 rounded-full bg-slate-950 border-2 border-slate-700 flex items-center justify-center relative shadow-inner">
              <Wind className={`w-10 h-10 transition-transform duration-300 ${
                testPhase === 'blasting' ? 'text-cyan-400 scale-125' : testPhase === 'inhaling' ? 'text-sky-300 scale-95' : 'text-slate-500'
              }`} />
              {testPhase === 'blasting' && (
                <div className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping opacity-40 pointer-events-none" />
              )}
            </div>

            <div className="space-y-1">
              <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
                {testPhase === 'idle' && 'READY FOR MANEUVER'}
                {testPhase === 'inhaling' && 'STEP 1: INHALE DEEPLY TO TLC...'}
                {testPhase === 'blasting' && 'STEP 2: BLAST OUT AS FAST AS POSSIBLE!'}
                {testPhase === 'completed' && 'TEST CRITERIA MET (ATS/ERS 2019)'}
              </span>
              <p className="text-xs text-slate-300 max-w-xs mx-auto">
                {testPhase === 'idle' && 'Click Start to perform a clinical forced vital capacity (FVC) breath test.'}
                {testPhase === 'inhaling' && 'Filling lungs to Total Lung Capacity.'}
                {testPhase === 'blasting' && 'Maximal expiratory effort with dynamic airway compression.'}
                {testPhase === 'completed' && 'Volume-time plateau > 1.0s and FET > 6s confirmed.'}
              </p>
            </div>

            <div className="flex items-center gap-3 w-full">
              {testPhase === 'idle' ? (
                <button
                  onClick={startSpirometryTest}
                  className="flex-1 py-3 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Execute FVC Maneuver</span>
                </button>
              ) : (
                <button
                  onClick={resetTest}
                  className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset Test</span>
                </button>
              )}
            </div>
          </div>

          {/* ATS/ERS 2019 Standard Parameters Table */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
            <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider block">
              Calculated Spirometric Indices
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">FVC (Volume)</span>
                <div className="text-base font-bold font-mono text-white mt-0.5">
                  {activeP.fvc.toFixed(2)} <span className="text-xs font-normal text-slate-400">Liters</span>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">FEV₁ (1st Second)</span>
                <div className="text-base font-bold font-mono text-cyan-400 mt-0.5">
                  {activeP.fev1.toFixed(2)} <span className="text-xs font-normal text-slate-400">Liters</span>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">FEV₁ / FVC Ratio</span>
                <div className={`text-base font-bold font-mono mt-0.5 ${
                  activeP.ratio < 70 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {activeP.ratio.toFixed(1)}%
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Peak Flow (PEF)</span>
                <div className="text-base font-bold font-mono text-white mt-0.5">
                  {activeP.pef.toFixed(1)} <span className="text-xs font-normal text-slate-400">L/s</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Dual Scientific Charts & Compartments */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          {/* Chart 1: Volume-Time Curve (V vs t) */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-cyan-400" /> Curve 1: Expiratory Volume vs. Time
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                FEV₁ at t=1.0s · Plateau at FVC
              </span>
            </div>

            {/* SVG Volume-Time Chart */}
            <div className="relative w-full h-[180px] bg-slate-950 rounded-xl p-2 border border-slate-800/80 flex items-center justify-center">
              <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-full">
                {/* Grid Lines */}
                {[1, 2, 3, 4, 5].map(v => (
                  <line
                    key={v}
                    x1="40"
                    y1={chartH - 25 - (v / maxVol) * (chartH - 45)}
                    x2={chartW - 20}
                    y2={chartH - 25 - (v / maxVol) * (chartH - 45)}
                    stroke="rgba(51, 65, 85, 0.4)"
                    strokeDasharray="3 3"
                  />
                ))}
                {[1, 2, 3, 4, 5].map(t => (
                  <line
                    key={t}
                    x1={40 + (t / maxTime) * (chartW - 60)}
                    y1="15"
                    x2={40 + (t / maxTime) * (chartW - 60)}
                    y2={chartH - 25}
                    stroke="rgba(51, 65, 85, 0.4)"
                    strokeDasharray="3 3"
                  />
                ))}

                {/* Axes */}
                <line x1="40" y1={chartH - 25} x2={chartW - 20} y2={chartH - 25} stroke="#64748b" strokeWidth="1.5" />
                <line x1="40" y1="15" x2="40" y2={chartH - 25} stroke="#64748b" strokeWidth="1.5" />

                {/* Axis Labels */}
                <text x="12" y="20" fill="#94a3b8" fontSize="10" fontFamily="sans-serif">L</text>
                <text x={chartW - 25} y={chartH - 10} fill="#94a3b8" fontSize="10" fontFamily="sans-serif">sec</text>

                {/* Plot Curve */}
                {displayPoints.length > 1 && (
                  <path
                    d={displayPoints.reduce((acc, pt, i) => {
                      const x = 40 + (Math.max(0, pt.time - 1.5) / 4.5) * (chartW - 60);
                      const y = chartH - 25 - (pt.volume / maxVol) * (chartH - 45);
                      return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
                    }, '')}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                  />
                )}

                {/* FEV1 marker at 1.0 second */}
                <line
                  x1={40 + (1.0 / 4.5) * (chartW - 60)}
                  y1="15"
                  x2={40 + (1.0 / 4.5) * (chartW - 60)}
                  y2={chartH - 25}
                  stroke="#f43f5e"
                  strokeWidth="1.5"
                  strokeDasharray="2 2"
                />
                <circle
                  cx={40 + (1.0 / 4.5) * (chartW - 60)}
                  cy={chartH - 25 - (activeP.fev1 / maxVol) * (chartH - 45)}
                  r="4"
                  fill="#f43f5e"
                />
                <text
                  x={45 + (1.0 / 4.5) * (chartW - 60)}
                  y={chartH - 30 - (activeP.fev1 / maxVol) * (chartH - 45)}
                  fill="#fda4af"
                  fontSize="10"
                  fontFamily="monospace"
                >
                  FEV₁: {activeP.fev1}L
                </text>
              </svg>
            </div>
          </div>

          {/* Chart 2: Flow-Volume Loop (Flow vs Volume) */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-cyan-400" /> Curve 2: Flow-Volume Loop (PEF &amp; Scooping)
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                X: Volume (L) · Y: Flow (L/s)
              </span>
            </div>

            <div className="relative w-full h-[180px] bg-slate-950 rounded-xl p-2 border border-slate-800/80 flex items-center justify-center">
              <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-full">
                {/* Horizontal Baseline (Flow = 0) */}
                <line x1="40" y1={chartH * 0.72} x2={chartW - 20} y2={chartH * 0.72} stroke="#64748b" strokeWidth="1.5" />
                <line x1="40" y1="15" x2="40" y2={chartH - 15} stroke="#64748b" strokeWidth="1.5" />

                <text x="10" y="20" fill="#94a3b8" fontSize="10" fontFamily="sans-serif">+Flow</text>
                <text x={chartW - 30} y={chartH * 0.72 - 5} fill="#94a3b8" fontSize="10" fontFamily="sans-serif">Vol (L)</text>

                {/* Expiratory Flow-Volume loop curve */}
                {displayPoints.length > 1 && (
                  <path
                    d={displayPoints.reduce((acc, pt, i) => {
                      const x = 40 + (pt.volume / maxVol) * (chartW - 60);
                      const y = (chartH * 0.72) - (pt.flow / maxFlow) * (chartH * 0.65);
                      return `${acc} ${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
                    }, '')}
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                  />
                )}

                {/* Simulated Inspiratory Loop at bottom */}
                <path
                  d={`M 40 ${(chartH * 0.72)} Q ${40 + (activeP.fvc / maxVol) * (chartW - 60) * 0.5} ${chartH - 15} ${40 + (activeP.fvc / maxVol) * (chartW - 60)} ${(chartH * 0.72)}`}
                  fill="none"
                  stroke="#64748b"
                  strokeWidth="1.5"
                  strokeDasharray="3 3"
                />
              </svg>
            </div>
          </div>

          {/* Classical Compartment Volumes Breakdown */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
            <span className="font-semibold text-slate-300 block">Total Lung Capacity (TLC) Compartments</span>
            <div className="flex h-6 rounded-lg overflow-hidden font-mono text-[10px] text-slate-950 font-bold">
              <div style={{ width: `${(activeP.rv / 5.8) * 100}%` }} className="bg-amber-400 flex items-center justify-center" title="Residual Volume (RV)">
                RV
              </div>
              <div style={{ width: `${(activeP.erv / 5.8) * 100}%` }} className="bg-sky-400 flex items-center justify-center" title="Expiratory Reserve Volume (ERV)">
                ERV
              </div>
              <div style={{ width: `${(activeP.vt / 5.8) * 100}%` }} className="bg-emerald-400 flex items-center justify-center" title="Tidal Volume (VT)">
                VT
              </div>
              <div style={{ width: `${(activeP.irv / 5.8) * 100}%` }} className="bg-cyan-300 flex items-center justify-center" title="Inspiratory Reserve Volume (IRV)">
                IRV
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              <strong className="text-amber-400">Important ATS Rule:</strong> Residual Volume ({activeP.rv} L) cannot be expelled or measured by basic spirometry alone; helium dilution or body plethysmography is mandatory to calculate FRC and TLC.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
