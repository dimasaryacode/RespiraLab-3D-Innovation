import React, { useState } from 'react';
import { ExperimentTrial, LabStage } from '../types/respiratory';
import { 
  FlaskConical, 
  Activity, 
  Wind, 
  Mountain, 
  User, 
  AlertTriangle, 
  PlusCircle, 
  ArrowRight,
  TrendingUp,
  BookOpen
} from 'lucide-react';

interface RespiratoryRateLabProps {
  onLogTrial: (trial: ExperimentTrial) => void;
  onNextStage?: (stage: LabStage) => void;
  trialsCount: number;
}

export const RespiratoryRateLab: React.FC<RespiratoryRateLabProps> = ({
  onLogTrial,
  onNextStage,
  trialsCount
}) => {
  // Independent variables
  const [ageGroup, setAgeGroup] = useState<'infant' | 'child' | 'adult' | 'elderly'>('adult');
  const [activity, setActivity] = useState<'rest' | 'walk' | 'cycle' | 'sprint'>('rest');
  const [altitude, setAltitude] = useState<number>(0); // 0, 1600, 3400, 5364 meters
  const [pathology, setPathology] = useState<'none' | 'kussmaul' | 'opioid' | 'panic'>('none');
  const [justLogged, setJustLogged] = useState(false);

  // Biological calculations
  // 1. Baseline by age
  const ageBaselines = {
    infant: { rr: 40, vt: 35, deadSpace: 12 },
    child: { rr: 22, vt: 200, deadSpace: 60 },
    adult: { rr: 14, vt: 500, deadSpace: 150 },
    elderly: { rr: 18, vt: 440, deadSpace: 160 }
  };

  const base = ageBaselines[ageGroup];

  // 2. Multipliers from activity
  const activityMultipliers = {
    rest: { rrMul: 1.0, vtMul: 1.0 },
    walk: { rrMul: 1.3, vtMul: 1.6 },
    cycle: { rrMul: 1.9, vtMul: 2.8 },
    sprint: { rrMul: 3.0, vtMul: 4.2 }
  };

  const act = activityMultipliers[activity];

  // 3. Altitude hypoxic drive (Carotid body stimulation)
  let altRrBonus = 0;
  if (altitude === 1600) altRrBonus = 2;
  else if (altitude === 3400) altRrBonus = 6;
  else if (altitude === 5364) altRrBonus = 14;

  // 4. Pathological modifiers
  let finalRR = Math.round(base.rr * act.rrMul + altRrBonus);
  let finalVT = Math.round(base.vt * act.vtMul);

  if (pathology === 'kussmaul') {
    finalRR = 32;
    finalVT = Math.round(finalVT * 1.8); // Deep & rapid
  } else if (pathology === 'opioid') {
    finalRR = 4; // Severe bradypnea
    finalVT = Math.round(finalVT * 0.7);
  } else if (pathology === 'panic') {
    finalRR = 36;
    finalVT = Math.round(base.vt * 0.5); // Rapid shallow
  }

  // Minute Ventilation VE (L/min)
  const minuteVentilation = (finalRR * finalVT) / 1000;
  // Alveolar Ventilation VA (L/min)
  const alveolarVentilation = (finalRR * Math.max(0, finalVT - base.deadSpace)) / 1000;

  // Estimated Blood Gases
  // Normal sea level: PaO2 = 98 mmHg, PaCO2 = 40 mmHg, pH = 7.40
  // Barometric pressure PB
  const pb = Math.round(760 * Math.exp(-altitude / 7000));
  const pio2 = Math.round(0.21 * (pb - 47));
  
  let paco2 = 40;
  if (pathology === 'kussmaul') paco2 = 22;
  else if (pathology === 'opioid') paco2 = 72;
  else if (pathology === 'panic') paco2 = 25;
  else if (altitude > 0) paco2 = Math.max(24, Math.round(40 - altRrBonus * 1.1));

  let pao2 = Math.max(35, Math.round(pio2 - paco2 / 0.8));
  if (pathology === 'opioid') pao2 = 45;

  let ph = 7.40 + (40 - paco2) * 0.008;
  if (pathology === 'kussmaul') ph = 7.15; // primary metabolic acidosis
  if (pathology === 'opioid') ph = 7.18; // primary acute respiratory acidosis

  const handleRecordTrial = () => {
    const trial: ExperimentTrial = {
      id: `trial_${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      subjectCondition: `${ageGroup.toUpperCase()} · ${activity.toUpperCase()}`,
      ageGroup,
      activityLevel: activity,
      altitude,
      pathology,
      respiratoryRate: finalRR,
      tidalVolume: finalVT,
      deadSpace: base.deadSpace,
      minuteVentilation: parseFloat(minuteVentilation.toFixed(2)),
      alveolarVentilation: parseFloat(alveolarVentilation.toFixed(2)),
      paO2Est: pao2,
      paCO2Est: paco2,
      phEst: parseFloat(ph.toFixed(2))
    };

    onLogTrial(trial);
    setJustLogged(true);
    setTimeout(() => setJustLogged(false), 2000);
  };

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 06 · Comparative Exercise &amp; Environmental Physiology</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Respiratory Rate &amp; Ventilatory Dynamics Lab</h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400">
            Recorded Trials: <span className="font-mono text-cyan-400 font-bold">{trialsCount}</span>
          </div>
          {onNextStage && (
            <button
              onClick={() => onNextStage('analysis')}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Data Analysis</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Experimental Parameter Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Factor 1: Age Demographic */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-cyan-400" /> 1. Age Cohort
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'infant', label: 'Infant (6m)', note: '40 bpm' },
              { id: 'child', label: 'Child (8y)', note: '22 bpm' },
              { id: 'adult', label: 'Adult (24y)', note: '14 bpm' },
              { id: 'elderly', label: 'Elderly (75y)', note: '18 bpm' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setAgeGroup(item.id as any)}
                className={`p-2.5 rounded-xl text-left transition-all border ${
                  ageGroup === item.id
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-slate-100'
                }`}
              >
                <div className="text-xs font-semibold">{item.label}</div>
                <div className={`text-[10px] ${ageGroup === item.id ? 'text-slate-900' : 'text-slate-400'}`}>
                  {item.note}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Factor 2: Exertional Metabolic Workload */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" /> 2. Physical Exertion
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'rest', label: 'Rest Supine', note: '1x MET' },
              { id: 'walk', label: 'Light Walk', note: '3x METs' },
              { id: 'cycle', label: 'Moderate Cycle', note: '6x METs' },
              { id: 'sprint', label: 'VO₂ Max Sprint', note: '14x METs' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setActivity(item.id as any)}
                className={`p-2.5 rounded-xl text-left transition-all border ${
                  activity === item.id
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-slate-100'
                }`}
              >
                <div className="text-xs font-semibold">{item.label}</div>
                <div className={`text-[10px] ${activity === item.id ? 'text-slate-900' : 'text-slate-400'}`}>
                  {item.note}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Factor 3: Hypobaric Altitude */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <Mountain className="w-3.5 h-3.5 text-cyan-400" /> 3. Altitude / Hypoxia
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[
              { alt: 0, label: 'Sea Level', pb: '760 mmHg' },
              { alt: 1600, label: 'Denver (1.6k m)', pb: '630 mmHg' },
              { alt: 3400, label: 'Cusco (3.4k m)', pb: '510 mmHg' },
              { alt: 5364, label: 'Everest (5.4k m)', pb: '380 mmHg' },
            ].map(item => (
              <button
                key={item.alt}
                onClick={() => setAltitude(item.alt)}
                className={`p-2.5 rounded-xl text-left transition-all border ${
                  altitude === item.alt
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-slate-100'
                }`}
              >
                <div className="text-xs font-semibold">{item.label}</div>
                <div className={`text-[10px] ${altitude === item.alt ? 'text-slate-900' : 'text-slate-400'}`}>
                  {item.pb}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Factor 4: Clinical Pathology */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-cyan-400" /> 4. Clinical State
          </span>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'none', label: 'Eupneic Normal' },
              { id: 'kussmaul', label: 'Kussmaul (DKA)' },
              { id: 'opioid', label: 'Opioid Toxicity' },
              { id: 'panic', label: 'Panic Alkalosis' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setPathology(item.id as any)}
                className={`p-2.5 rounded-xl text-left transition-all border ${
                  pathology === item.id
                    ? 'bg-rose-500 text-slate-950 border-rose-400 font-semibold'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-slate-100'
                }`}
              >
                <div className="text-xs font-semibold">{item.label}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Live Ventilatory Output & Blood Gas Estimation Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Animated Chest Cycle Visualizer (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between items-center text-center space-y-4">
          <div className="w-full flex justify-between items-center border-b border-slate-800 pb-3">
            <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Thoracic Excursion Rhythm
            </span>
            <span className="text-xs font-mono text-cyan-400">{finalRR} Breaths / Min</span>
          </div>

          {/* Oscillating Thorax Diagram */}
          <div className="relative w-44 h-44 flex items-center justify-center">
            <div
              className="absolute rounded-full border-4 border-cyan-400/40 bg-cyan-950/40 transition-transform"
              style={{
                width: '140px',
                height: '140px',
                animation: `pulse ${Math.max(0.6, 60 / finalRR)}s ease-in-out infinite`
              }}
            />
            <div className="relative z-10 space-y-1">
              <Wind className="w-8 h-8 text-cyan-400 mx-auto" />
              <div className="text-2xl font-mono font-bold text-white">{finalRR}</div>
              <div className="text-[10px] text-slate-400 font-mono">BPM</div>
            </div>
          </div>

          <div className="w-full grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Tidal Volume (VT)</span>
              <div className="text-lg font-bold font-mono text-cyan-400 mt-1">{finalVT} mL</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Dead Space (VD)</span>
              <div className="text-lg font-bold font-mono text-slate-300 mt-1">{base.deadSpace} mL</div>
            </div>
          </div>

          <button
            onClick={handleRecordTrial}
            className={`w-full py-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 shadow-md ${
              justLogged
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-cyan-400 hover:bg-cyan-300 text-slate-950'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>{justLogged ? 'Trial Logged Successfully!' : 'Log Trial to Data Analysis Table'}</span>
          </button>
        </div>

        {/* Right: Calculated Minute & Alveolar Ventilation + Blood Gases (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Real-Time Ventilation &amp; Arterial Gas Calculations
            </span>
            <span className="text-xs font-mono text-slate-400">VE vs VA Differentiation</span>
          </div>

          {/* Key Metrics: Minute vs Alveolar Ventilation */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
              <span className="text-xs text-slate-400 font-semibold uppercase">Minute Ventilation (V̇E)</span>
              <div className="text-2xl font-mono font-bold text-white">
                {minuteVentilation.toFixed(2)} <span className="text-xs font-normal text-slate-400">L/min</span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">Formula: RR × VT</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-cyan-800/50 space-y-1 bg-cyan-950/20">
              <span className="text-xs text-cyan-400 font-semibold uppercase">Alveolar Ventilation (V̇A)</span>
              <div className="text-2xl font-mono font-bold text-cyan-300">
                {alveolarVentilation.toFixed(2)} <span className="text-xs font-normal text-slate-400">L/min</span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">Formula: RR × (VT - VD)</div>
            </div>
          </div>

          {/* Blood Gas Estimation Bar */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-3">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
              Estimated Arterial Blood Gases (ABG)
            </span>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Arterial PaO₂</span>
                <span className={`text-lg font-mono font-bold block mt-1 ${pao2 < 60 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {pao2} <span className="text-xs font-normal text-slate-400">mmHg</span>
                </span>
                <span className="text-[10px] text-slate-500">{pao2 < 60 ? 'Hypoxemic' : 'Nominal'}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Arterial PaCO₂</span>
                <span className={`text-lg font-mono font-bold block mt-1 ${paco2 > 45 ? 'text-rose-400' : paco2 < 35 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {paco2} <span className="text-xs font-normal text-slate-400">mmHg</span>
                </span>
                <span className="text-[10px] text-slate-500">{paco2 > 45 ? 'Hypercapnia' : paco2 < 35 ? 'Hypocapnia' : 'Eucapnic'}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Arterial pH</span>
                <span className={`text-lg font-mono font-bold block mt-1 ${ph < 7.35 ? 'text-rose-400' : ph > 7.45 ? 'text-sky-400' : 'text-emerald-400'}`}>
                  {ph.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500">{ph < 7.35 ? 'Acidemia' : ph > 7.45 ? 'Alkalemia' : 'Normal'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 pt-2 border-t border-slate-800">
            <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Guyton &amp; Hall, Chapter 42: Regulation of Respiration &amp; Carotid Chemoreceptors</span>
          </div>
        </div>
      </div>
    </div>
  );
};
