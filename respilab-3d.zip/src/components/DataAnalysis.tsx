import React, { useState } from 'react';
import { ExperimentTrial, LabStage } from '../types/respiratory';
import { 
  BarChart3, 
  Calculator, 
  Download, 
  Trash2, 
  ArrowRight,
  TrendingUp,
  Table as TableIcon,
  CheckCircle2
} from 'lucide-react';

interface DataAnalysisProps {
  trials: ExperimentTrial[];
  onClearTrials: () => void;
  onNextStage?: (stage: LabStage) => void;
}

export const DataAnalysis: React.FC<DataAnalysisProps> = ({
  trials,
  onClearTrials,
  onNextStage
}) => {
  // Alveolar Gas Equation Interactive Playground State
  // PAO2 = FiO2 * (PB - 47) - (PaCO2 / R)
  const [fiO2Percent, setFiO2Percent] = useState<number>(21); // % (21 to 100)
  const [barometricPressure, setBarometricPressure] = useState<number>(760); // mmHg
  const [inputPaCO2, setInputPaCO2] = useState<number>(40); // mmHg
  const [respExchangeRatio, setRespExchangeRatio] = useState<number>(0.8); // R (usually 0.8)
  const [patientPaO2, setPatientPaO2] = useState<number>(95); // mmHg

  // Calculations
  const pWaterVapor = 47; // mmHg at 37C
  const calculatedPAO2 = Math.max(0, (fiO2Percent / 100) * (barometricPressure - pWaterVapor) - (inputPaCO2 / respExchangeRatio));
  const calculatedAaGradient = Math.max(0, calculatedPAO2 - patientPaO2);

  // Normal A-a gradient rule of thumb: (Age / 4) + 4, typically < 15-20 mmHg in young adult
  const isAaElevated = calculatedAaGradient > 15;

  // CSV Export handler
  const exportToCSV = () => {
    if (trials.length === 0) return;
    const headers = [
      'ID', 'Timestamp', 'Condition', 'Age_Group', 'Activity', 'Altitude_m',
      'Pathology', 'RR_bpm', 'VT_mL', 'VD_mL', 'VE_L_min', 'VA_L_min',
      'PaO2_est', 'PaCO2_est', 'pH_est'
    ];
    const rows = trials.map(t => [
      t.id, t.timestamp, `"${t.subjectCondition}"`, t.ageGroup, t.activityLevel,
      t.altitude, t.pathology, t.respiratoryRate, t.tidalVolume, t.deadSpace,
      t.minuteVentilation, t.alveolarVentilation, t.paO2Est, t.paCO2Est, t.phEst
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `pulmolab_trials_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Stage 07 · Quantitative Biostatistics &amp; Equations</span>
          <h2 className="font-display text-2xl font-bold text-white mt-1">Data Analysis &amp; Alveolar Gas Calculations</h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportToCSV}
            disabled={trials.length === 0}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 disabled:opacity-40 rounded-xl text-xs font-semibold transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>

          {onNextStage && (
            <button
              onClick={() => onNextStage('engineering')}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold text-xs rounded-xl transition-colors shadow-sm"
            >
              <span>Proceed to Engineering Challenge</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Alveolar Gas Equation Interactive Calculator */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-cyan-400" />
              <h3 className="font-display text-lg font-bold text-white">The Clinical Alveolar Gas Equation</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              PAO₂ = FiO₂ × (PB - 47) - (PaCO₂ / R) · Determines ideal alveolar oxygen tension and A-a gradient.
            </p>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300">
            P_H2O at 37°C = 47 mmHg
          </div>
        </div>

        {/* Input Parameters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* FiO2 */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">Fractional O₂ (FiO₂)</span>
            <div className="flex items-center justify-between font-mono text-cyan-400 font-bold text-sm">
              <span>{fiO2Percent}%</span>
              <span className="text-[10px] text-slate-500 font-normal">{fiO2Percent === 21 ? 'Room Air' : 'Supplemental'}</span>
            </div>
            <input
              type="range"
              min="21"
              max="100"
              value={fiO2Percent}
              onChange={e => setFiO2Percent(parseInt(e.target.value))}
              className="w-full accent-cyan-400 h-1 bg-slate-800 rounded cursor-pointer"
            />
          </div>

          {/* Barometric Pressure PB */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">Barometric (PB)</span>
            <div className="flex items-center justify-between font-mono text-white font-bold text-sm">
              <span>{barometricPressure} mmHg</span>
            </div>
            <input
              type="range"
              min="350"
              max="760"
              value={barometricPressure}
              onChange={e => setBarometricPressure(parseInt(e.target.value))}
              className="w-full accent-cyan-400 h-1 bg-slate-800 rounded cursor-pointer"
            />
          </div>

          {/* Arterial PaCO2 */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">Arterial PaCO₂</span>
            <div className="flex items-center justify-between font-mono text-white font-bold text-sm">
              <span>{inputPaCO2} mmHg</span>
            </div>
            <input
              type="range"
              min="15"
              max="80"
              value={inputPaCO2}
              onChange={e => setInputPaCO2(parseInt(e.target.value))}
              className="w-full accent-cyan-400 h-1 bg-slate-800 rounded cursor-pointer"
            />
          </div>

          {/* Measured Patient PaO2 */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">Measured Arterial PaO₂</span>
            <div className="flex items-center justify-between font-mono text-white font-bold text-sm">
              <span>{patientPaO2} mmHg</span>
            </div>
            <input
              type="range"
              min="30"
              max="150"
              value={patientPaO2}
              onChange={e => setPatientPaO2(parseInt(e.target.value))}
              className="w-full accent-cyan-400 h-1 bg-slate-800 rounded cursor-pointer"
            />
          </div>

          {/* Exchange Ratio R */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 font-medium">Exchange Ratio (R)</span>
            <div className="flex items-center justify-between font-mono text-white font-bold text-sm">
              <span>{respExchangeRatio.toFixed(1)}</span>
            </div>
            <div className="flex gap-1 pt-1">
              {[0.7, 0.8, 1.0].map(r => (
                <button
                  key={r}
                  onClick={() => setRespExchangeRatio(r)}
                  className={`flex-1 py-0.5 text-[10px] rounded border ${
                    respExchangeRatio === r
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Calculated Results Strip */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-semibold uppercase block">
                Calculated Alveolar O₂ Tension (PAO₂)
              </span>
              <p className="text-xs text-slate-500 mt-0.5">Theoretical ideal partial pressure in alveoli</p>
            </div>
            <div className="text-3xl font-mono font-bold text-cyan-400">
              {calculatedPAO2.toFixed(1)} <span className="text-xs font-normal text-slate-400">mmHg</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 font-semibold uppercase block">
                Alveolar-Arterial (A-a) Gradient
              </span>
              <p className="text-xs text-slate-500 mt-0.5">
                {isAaElevated ? '⚠️ Elevated (>15 mmHg) - Indicates V/Q Mismatch, Shunt, or Diffusion Defect' : '✓ Normal Gradient (<15 mmHg)'}
              </p>
            </div>
            <div className={`text-3xl font-mono font-bold ${isAaElevated ? 'text-rose-400' : 'text-emerald-400'}`}>
              {calculatedAaGradient.toFixed(1)} <span className="text-xs font-normal text-slate-400">mmHg</span>
            </div>
          </div>
        </div>
      </div>

      {/* Experimental Trials Logged Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <TableIcon className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display text-lg font-bold text-white">Experimental Ventilation Registry</h3>
            <span className="text-xs text-slate-400">({trials.length} logged runs)</span>
          </div>

          {trials.length > 0 && (
            <button
              onClick={onClearTrials}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Table</span>
            </button>
          )}
        </div>

        {trials.length === 0 ? (
          <div className="p-8 text-center space-y-2 border border-dashed border-slate-800 rounded-2xl">
            <BarChart3 className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs text-slate-400">
              No experimental trials logged yet. Return to Stage 6 (Respiratory Rate Lab) to record comparison trials across age, exercise load, and altitude.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3">Condition</th>
                  <th className="py-3 px-3">Altitude</th>
                  <th className="py-3 px-3">RR (bpm)</th>
                  <th className="py-3 px-3">VT (mL)</th>
                  <th className="py-3 px-3">V̇E (L/min)</th>
                  <th className="py-3 px-3 text-cyan-400">V̇A (L/min)</th>
                  <th className="py-3 px-3">PaO₂ (est)</th>
                  <th className="py-3 px-3">PaCO₂ (est)</th>
                  <th className="py-3 px-3">pH</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums text-slate-300">
                {trials.map((trial) => (
                  <tr key={trial.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-sans font-medium text-white">{trial.subjectCondition}</td>
                    <td className="py-2.5 px-3">{trial.altitude}m</td>
                    <td className="py-2.5 px-3">{trial.respiratoryRate}</td>
                    <td className="py-2.5 px-3">{trial.tidalVolume}</td>
                    <td className="py-2.5 px-3">{trial.minuteVentilation}</td>
                    <td className="py-2.5 px-3 text-cyan-300 font-bold">{trial.alveolarVentilation}</td>
                    <td className="py-2.5 px-3">{trial.paO2Est}</td>
                    <td className="py-2.5 px-3">{trial.paCO2Est}</td>
                    <td className="py-2.5 px-3">{trial.phEst}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
