import React from 'react';
import { LabStage } from '../types/respiratory';
import { LAB_STAGES } from '../data/stagesData';
import { CheckCircle2, ChevronRight } from 'lucide-react';

interface StationSelectorProps {
  currentStage: LabStage;
  onSelectStage: (stage: LabStage) => void;
  completedStages: LabStage[];
}

export const StationSelector: React.FC<StationSelectorProps> = ({
  currentStage,
  onSelectStage,
  completedStages
}) => {
  return (
    <div className="bg-slate-900/90 border-b border-slate-800/80 px-4 py-2.5 overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 min-w-max">
        <div className="flex items-center gap-1.5">
          {LAB_STAGES.map((stage, idx) => {
            const isActive = currentStage === stage.id;
            const isCompleted = completedStages.includes(stage.id);

            return (
              <React.Fragment key={stage.id}>
                <button
                  onClick={() => onSelectStage(stage.id)}
                  className={`group flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-300'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-mono ${
                      isActive
                        ? 'bg-cyan-400 text-slate-950 font-bold'
                        : isCompleted
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isCompleted ? '✓' : stage.number}
                  </span>
                  <span>{stage.title}</span>
                </button>
                {idx < LAB_STAGES.length - 1 && (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-700 shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};
